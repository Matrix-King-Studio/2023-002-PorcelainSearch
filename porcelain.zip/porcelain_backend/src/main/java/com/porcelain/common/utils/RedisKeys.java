/**
 * Copyright (c) 2016-2019 人人开源 All rights reserved.
 *
 * https://www.renren.io
 *
 * 版权所有，侵权必究！
 */

package com.porcelain.common.utils;

import java.io.Serializable;

/**
 * Redis所有Keys
 *
 * @author Mark sunlightcs@gmail.com
 */
public class RedisKeys {

    public static String getSysConfigKey(String key){
        return "porcelain: sys: config: " + key;
    }

    /**
     * TODO 邮箱验证码 key
     */
    public static String getEmailKey(String email) {
        return "porcelain: email: " + email;
    }

    /**
     * TODO 用户的关注列表 key
     */
    public static String getUserFollowKey(Serializable userId) {
        return "porcelain: user: " + userId + ": follow";
    }

    /**
     * TODO 用户的粉丝列表 key
     */
    public static String getUserFanKey(Serializable userId) {
        return "porcelain: user: " + userId + ": fan";
    }

    /**
     * TODO 用户的访客数 key
     */
    public static String getUserVisitCntKey(Serializable userId) {
        return "porcelain: user: " + userId + ": visitCnt";
    }

    /**
     * TODO 用户的喜欢数 key
     */
    public static String getUserLoveCntKey(Serializable userId) {
        return "porcelain: user: " + userId + ": loveCnt";
    }

    /**
     * TODO 点赞这篇文章的用户 key
     */
    public static String getArticleLoveKey(Long articleId) {
        return "porcelain: article: " + articleId + ": love";
    }

    /**
     * TODO 点赞评论的用户 key
     */
    public static String getCommentLoveKey(Long commentId) {
        return "porcelain: comment: " + commentId + ": love";
    }


}
