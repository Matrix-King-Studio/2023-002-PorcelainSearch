package com.porcelain.common.utils;

import cn.hutool.core.util.StrUtil;
import com.porcelain.common.exception.GlobalException;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;


/**
 * @description: TODO 读取邮箱
 * @author nuo
 * @date 2022/12/5 2:28
 * @version 1.0
 */
@Data
@Component
@Slf4j
@ConfigurationProperties(prefix = "spring.mail")
public class EmailUtil {

    @Resource
    private JavaMailSender mailSender;

    private String username;
    private String subject;
    private String text;



    public void send(String email, String subject, String text) {
        try {
            SimpleMailMessage mailMessage = new SimpleMailMessage();
            mailMessage.setFrom(username);
            mailMessage.setTo(email);
            mailMessage.setSubject(StrUtil.isBlank(subject) ? this.subject : subject);
            mailMessage.setText(StrUtil.isBlank(text) ? this.text : text);
            mailSender.send(mailMessage);
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new GlobalException("邮箱发送失败...");
        }
    }

}
