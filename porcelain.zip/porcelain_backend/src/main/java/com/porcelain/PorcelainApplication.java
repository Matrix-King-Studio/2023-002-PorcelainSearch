package com.porcelain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class PorcelainApplication {

	public static void main(String[] args) {
		SpringApplication.run(PorcelainApplication.class, args);
	}

}