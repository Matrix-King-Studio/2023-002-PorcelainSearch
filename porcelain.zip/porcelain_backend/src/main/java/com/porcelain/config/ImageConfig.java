package com.porcelain.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @description: TODO
 * @author nuo
 * @date 2023/2/16 18:03
 * @version 1.0
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "img")
public class ImageConfig {
    private String appId;
    private String apiKey;
    private String secretKey;

}
