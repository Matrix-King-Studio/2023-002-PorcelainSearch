package com.porcelain.modules.user.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.porcelain.common.utils.PageUtils;
import com.porcelain.common.utils.R;
import com.porcelain.modules.user.entity.UserEntity;
import com.porcelain.modules.user.po.FollowPO;
import com.porcelain.modules.user.po.UserPO;

import java.util.Map;

/**
 * 
 */
public interface UserService extends IService<UserEntity> {

    R login(UserPO po);

    R sendCode(UserEntity user);

    R register(UserPO po);

    R info();

    R info(Long id);

    R logoff();

    R list(Map<String, Object> params);

    R followUser(FollowPO po);
}

