package com.porcelain.modules.comment.controller;

import java.util.Map;

import com.porcelain.modules.comment.po.LovePO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.porcelain.modules.comment.entity.CommentEntity;
import com.porcelain.modules.comment.service.CommentService;
import com.porcelain.common.utils.R;



/**
 * TODO 评论
 */
@RestController
@RequestMapping("/comment")
public class CommentController {

    @Autowired
    private CommentService commentService;

    /**
     * TODO 发布评论
     */
    @PostMapping("/")
    public R add(@RequestBody CommentEntity comment){
        return commentService.add(comment);
    }

    /**
     * TODO 删除评论
     */
    @DeleteMapping("/")
    public R delete(@RequestBody CommentEntity comment){
        return commentService.del(comment);
    }

    /**
     * TODO 获取评论列表
     */
    @GetMapping("/list")
    public R list(@RequestParam Map<String, Object> params){
        return R.ok().put("list", commentService.list(params));
    }

    /**
     * TODO 点赞评论
     */
    @PostMapping("/love")
    public R love(@RequestBody LovePO po) {
        return commentService.love(po);
    }

}
