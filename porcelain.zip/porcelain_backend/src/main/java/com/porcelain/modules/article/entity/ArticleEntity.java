package com.porcelain.modules.article.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.porcelain.modules.comment.entity.CommentEntity;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * TODO 文章
 */
@Data
@TableName("article")
@Accessors(chain = true)
public class ArticleEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 帖子 id
	 */
	@TableId
	private Long id;
	/**
	 * 帖子标题
	 */
	private String title;
	/**
	 * 类型
	 */
	private String type;
	/**
	 * 内容
	 */
	private String content;
	/**
	 * 帖子的用户 id
	 */
	private Long userId;
	/**
	 * 帖子的用户名
	 */
	@TableField(exist = false)
	private String username;
	/**
	 * 帖子的用户头像
	 */
	@TableField(exist = false)
	private String avatar;

	/**
	 * 点赞数
	 */
	@TableField(exist = false)
	private Long loveCnt;

	/**
	 * 是否点赞
	 */
	@TableField(exist = false)
	private Integer loveStatus;
	/**
	 * 是否关注
	 */
	@TableField(exist = false)
	private Integer followStatus;
	/**
	 * 评论数
	 */
	@TableField(exist = false)
	private Integer commentCnt;
	/**
	 * 文章的所有父评论
	 */
	@TableField(exist = false)
	private List<CommentEntity> parentCommentList;
	/**
	 * 创建日期
	 */
	private Date gmtCreate;
	/**
	 * 修改日期
	 */
	private Date gmtModified;
	/**
	 * 逻辑删除
	 */
	private Integer isDeleted;

}
