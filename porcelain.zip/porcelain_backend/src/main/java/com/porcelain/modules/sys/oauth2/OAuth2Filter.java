package com.porcelain.modules.sys.oauth2;

import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.google.gson.Gson;
import com.porcelain.common.utils.HttpContextUtils;
import com.porcelain.common.utils.R;
import com.porcelain.common.utils.SpringContextUtils;
import com.porcelain.modules.sys.entity.SysUserTokenEntity;
import com.porcelain.modules.sys.service.SysUserTokenService;
import net.bytebuddy.description.modifier.MethodArguments;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpStatus;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.web.filter.authc.AuthenticatingFilter;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * oauth2过滤器
 *
 * @author Mark sunlightcs@gmail.com
 */
public class OAuth2Filter extends AuthenticatingFilter {

    @Override
    protected AuthenticationToken createToken(ServletRequest request, ServletResponse response) throws Exception {
        //获取请求 token
        String token = getRequestToken((HttpServletRequest) request);

        if(StringUtils.isBlank(token)){
            return null;
        }

        return new OAuth2Token(token);
    }

    @Override
    protected boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue) {
        if(((HttpServletRequest) request).getMethod().equals(RequestMethod.OPTIONS.name())){
            return true;
        }
        return false;
    }

    @Override
    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {
        if (((HttpServletRequest) request).getMethod().equals(RequestMethod.GET.name()) || ((HttpServletRequest) request).getMethod().equals(RequestMethod.OPTIONS.name())) {
            return true;
        } else {
            SysUserTokenService sysUserTokenService = SpringContextUtils.getBean("sysUserTokenService", SysUserTokenService.class);

            //获取请求token，如果token不存在，直接返回401
            String tokenStr = getRequestToken((HttpServletRequest) request);
            SysUserTokenEntity token = sysUserTokenService.getOne(new LambdaQueryWrapper<SysUserTokenEntity>().eq(SysUserTokenEntity::getToken, tokenStr));
            if (ObjectUtil.isNull(token)) {
                ServletOutputStream os = response.getOutputStream();
                os.write(JSONObject.toJSONString(R.error(401, "请先登陆...")).getBytes(StandardCharsets.UTF_8));
                os.flush();
                os.close();
                return false;
            }
            //token失效
            if(token.getExpireTime().getTime() < System.currentTimeMillis()){
                ServletOutputStream os = response.getOutputStream();
                os.write(JSONObject.toJSONString(R.error(401, "token失效, 请重新登录")).getBytes(StandardCharsets.UTF_8));
                os.flush();
                os.close();
                return false;
            }
            return true;
        }
    }

    @Override
    protected boolean onLoginFailure(AuthenticationToken token, AuthenticationException e, ServletRequest request, ServletResponse response) {
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        httpResponse.setContentType("application/json;charset=utf-8");
        httpResponse.setHeader("Access-Control-Allow-Credentials", "true");
        httpResponse.setHeader("Access-Control-Allow-Origin", HttpContextUtils.getOrigin());
        try {
            //处理登录失败的异常
            Throwable throwable = e.getCause() == null ? e : e.getCause();
            R r = R.error(HttpStatus.SC_UNAUTHORIZED, throwable.getMessage());

            String json = new Gson().toJson(r);
            httpResponse.getWriter().print(json);
        } catch (IOException e1) {

        }

        return false;
    }

    /**
     * 获取请求的token
     */
    private String getRequestToken(HttpServletRequest httpRequest){
        //从header中获取token
        String token = httpRequest.getHeader("token");

        //如果header中不存在token，则从参数中获取token
        if(StringUtils.isBlank(token)){
            token = httpRequest.getParameter("token");
        }

        return token;
    }


}
