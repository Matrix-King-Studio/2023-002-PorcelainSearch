package com.porcelain.modules.porcelain.service.impl;

import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.porcelain.common.utils.R;
import com.porcelain.modules.porcelain.dao.PorcelainDao;
import com.porcelain.modules.porcelain.entity.PorcelainEntity;
import com.porcelain.modules.porcelain.po.AddOrPutPO;
import com.porcelain.modules.porcelain.service.AIService;
import com.porcelain.modules.porcelain.service.PorcelainService;
import com.porcelain.modules.porcelain.vo.DynastyListVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;


@Service("porcelainService")
public class PorcelainServiceImpl extends ServiceImpl<PorcelainDao, PorcelainEntity> implements PorcelainService {

    @Lazy
    @Autowired
    private AIService aiService;

    @Override
    public R add(PorcelainEntity porcelain) {
        save(porcelain);
        aiService.add(new AddOrPutPO()
                .setImageUrl(porcelain.getUrl())
                .setBrief(porcelain.getId())
        );
        return R.ok("添加成功...");
    }

    @Override
    public R del(List<PorcelainEntity> porcelainList) {
        if (ObjectUtil.isNotEmpty(porcelainList)) {
            Map<Long, String> porcelainMap = porcelainList.stream().collect(Collectors.toMap(PorcelainEntity::getId, PorcelainEntity::getUrl));
            removeByIds(porcelainMap.keySet());
            porcelainMap.values().forEach(i -> aiService.del(i));
        }
        return R.ok();
    }

    @Override
    public R put(PorcelainEntity porcelain) {
        PorcelainEntity entity = getById(porcelain.getId());
        if (!Objects.equals(entity.getUrl(), porcelain.getUrl())) {
            aiService.del(entity.getUrl());
            aiService.add(new AddOrPutPO().setBrief(entity.getId()).setImageUrl(porcelain.getUrl()));
        }
        updateById(porcelain);
        return R.ok("修改成功...");
    }

    @Override
    public R list(Map<String, Object> params) {
        return R.ok().put("list", list(new LambdaQueryWrapper<PorcelainEntity>()
                        .eq(ObjectUtil.isNotEmpty(params.get("name")) && !params.get("name").toString().equals("全部"), PorcelainEntity::getDynasty, params.get("name"))
                        .and(
                                ObjectUtil.isNotEmpty(params.get("key")),
                                i -> i.like(PorcelainEntity::getTitle, params.get("key"))
                                        .or()
                                        .like(PorcelainEntity::getDynasty, params.get("key"))
                                        .or()
                                        .like(PorcelainEntity::getIntroduction, params.get("key"))
                                        .or()
                                        .like(PorcelainEntity::getDetail, params.get("key"))

                        ).orderByDesc(PorcelainEntity::getGmtCreate)
                )
        );
    }

    @Override
    public R dynastyList() {
        Set<String> set = list().stream().map(PorcelainEntity::getDynasty).collect(Collectors.toSet());
        List<DynastyListVO> res = new ArrayList<>();
        res.add(new DynastyListVO("全部"));
        res.add(new DynastyListVO("夏"));
        res.add(new DynastyListVO("商"));
        res.add(new DynastyListVO("周"));
        res.add(new DynastyListVO("春秋战国"));
        res.add(new DynastyListVO("唐"));
        res.add(new DynastyListVO("宋"));
        res.add(new DynastyListVO("元"));
        res.add(new DynastyListVO("明"));
        res.add(new DynastyListVO("清"));
        return R.ok().put("dynastyList", res);
    }

}