package com.porcelain.modules.porcelain.controller;

import com.porcelain.common.utils.R;
import com.porcelain.modules.porcelain.po.UrlPO;
import com.porcelain.modules.porcelain.service.AIService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * @description: TODO
 * @author nuo
 * @date 2023/3/7 19:33
 * @version 1.0
 */
@RestController
@RequestMapping("/ai")
public class AIController {

    @Autowired
    private AIService aiService;

    @PostMapping("/check")
    public R check(@RequestBody UrlPO po) {
        return aiService.check(po);
    }

}
