package com.porcelain.modules.user.po;

import lombok.Data;

/**
 * @description: TODO
 * @author nuo
 * @date 2023/3/5 2:35
 * @version 1.0
 */
@Data
public class FollowPO {
    /**
     * 用户 id
     */
    private Long id;
    /**
     * 关注状态(0: 未关注 | 1: 已关注)
     */
    private Integer status;
}
