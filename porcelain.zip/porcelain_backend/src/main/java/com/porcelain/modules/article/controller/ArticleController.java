package com.porcelain.modules.article.controller;

import com.porcelain.common.utils.PageUtils;
import com.porcelain.common.utils.R;
import com.porcelain.modules.article.entity.ArticleEntity;
import com.porcelain.modules.article.po.LovePO;
import com.porcelain.modules.article.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.Map;


/**
 * TODO 文章
 */
@RestController
@RequestMapping("/article")
public class ArticleController {

    @Autowired
    private ArticleService articleService;

    /**
     * TODO 发布文章
     */
    @PostMapping("/")
    public R publish(@RequestBody ArticleEntity article) {
        return articleService.publish(article);
    }

    /**
     * TODO 删
     */
    @DeleteMapping("/")
    public R del(@RequestBody Long[] articleIdList) {
        return articleService.del(articleIdList);
    }

    /**
     * TODO 查
     */
    @GetMapping("/{id}")
    public R info(@PathVariable("id") Long id) {
        return articleService.info(id);
    }


    /**
     * TODO 点赞文章
     */
    @PostMapping("/love")
    public R love(@RequestBody LovePO po) {
        return articleService.love(po);
    }


    /**
     * TODO 列表
     */
    @GetMapping("/list")
    public R list(@RequestParam Map<String, Object> params) {
        return R.ok().put("list", articleService.list(params));
    }

}
