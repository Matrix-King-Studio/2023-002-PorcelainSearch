package com.porcelain.modules.porcelain.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.porcelain.modules.porcelain.entity.PorcelainEntity;
import com.porcelain.modules.porcelain.service.PorcelainService;
import com.porcelain.common.utils.PageUtils;
import com.porcelain.common.utils.R;



/**
 * TODO 瓷器
 */
@RestController
@RequestMapping("/porcelain")
public class PorcelainController {

    @Autowired
    private PorcelainService porcelainService;

    /**
     * TODO 增
     */
    @PostMapping("/")
    public R save(@RequestBody PorcelainEntity porcelain){
        return porcelainService.add(porcelain);
    }

    /**
     * TODO 删
     */
    @DeleteMapping("/")
    public R delete(@RequestBody List<PorcelainEntity> porcelainList){
        return porcelainService.del(porcelainList);
    }

    /**
     * TODO 改
     */
    @PutMapping("/")
    public R update(@RequestBody PorcelainEntity porcelain){
        return porcelainService.put(porcelain);
    }

    /**
     * TODO 查
     */
    @GetMapping("/{id}")
    public R info(@PathVariable("id") Long id){
        return R.ok().put("porcelain", porcelainService.getById(id));
    }

    /**
     * TODO 列表
     */
    @GetMapping("/list")
    public R list(@RequestParam Map<String, Object> params){
        return porcelainService.list(params);
    }

    /**
     * TODO 朝代列表
     */
    @GetMapping("/dynastyList")
    public R dynastyList() {
        return porcelainService.dynastyList();
    }

}
