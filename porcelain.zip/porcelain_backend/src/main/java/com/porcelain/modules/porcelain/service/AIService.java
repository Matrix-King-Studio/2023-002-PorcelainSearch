package com.porcelain.modules.porcelain.service;

import com.porcelain.common.utils.R;
import com.porcelain.modules.porcelain.po.AddOrPutPO;
import com.porcelain.modules.porcelain.po.UrlPO;

public interface AIService {

    void add(AddOrPutPO po);

    void del(UrlPO po);

    void del(String imgUrl);

    void put(AddOrPutPO po);

    R check(UrlPO po);

}
