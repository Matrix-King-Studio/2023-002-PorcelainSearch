package com.porcelain.modules.user.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.porcelain.modules.article.entity.ArticleEntity;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * TODO 用户
 */
@Data
@TableName("user")
@Accessors(chain = true)
public class UserEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 用户 id
	 */
	@TableId
	private Long id;
	/**
	 * 头像
	 */
	private String avatar;
	/**
	 * 用户名
	 */
	private String username;
	/**
	 * 密码
	 */
	@JsonIgnore
	private String password;
	/**
	 * 邮箱
	 */
	private String email;
	/**
	 * 个性签名
	 */
	private String signature;


	/**
	 * 关注数
	 */
	@TableField(exist = false)
	private Long followCnt;
	/**
	 * 粉丝数
	 */
	@TableField(exist = false)
	private Long fanCnt;
	/**
	 * 访客数
	 */
	@TableField(exist = false)
	private Long visitCnt;
	/**
	 * 喜欢数
	 */
	@TableField(exist = false)
	private Long loveCnt;
	/**
	 * 是否关注
	 */
	@TableField(exist = false)
	private Integer followStatus;

	/**
	 * 文章列表
	 */
	@TableField(exist = false)
	private List<ArticleEntity> articleList;

 	/**
	 * 创建日期
	 */
	private Date gmtCreate;
	/**
	 * 修改日期
	 */
	private Date gmtModified;
	/**
	 * 逻辑删除
	 */
	private Integer isDeleted;

}
