package com.porcelain.modules.article.dao;

import com.porcelain.modules.article.entity.ArticleEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * TODO 文章
 */
@Mapper
public interface ArticleDao extends BaseMapper<ArticleEntity> {
	
}
