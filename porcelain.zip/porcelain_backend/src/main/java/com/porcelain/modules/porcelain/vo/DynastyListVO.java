package com.porcelain.modules.porcelain.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @description: TODO
 * @author nuo
 * @date 2023/3/14 17:25
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DynastyListVO {
    private String name;
}
