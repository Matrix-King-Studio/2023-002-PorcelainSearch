package com.porcelain.modules.user.controller;

import java.util.Arrays;
import java.util.Map;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.porcelain.common.utils.RedisUtils;
import com.porcelain.modules.user.po.FollowPO;
import com.porcelain.modules.user.po.UserPO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.porcelain.modules.user.entity.UserEntity;
import com.porcelain.modules.user.service.UserService;
import com.porcelain.common.utils.PageUtils;
import com.porcelain.common.utils.R;


/**
 * TODO 用户
 */
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    /**
     * TODO 登陆
     */
    @PostMapping("/login")
    public R login(@RequestBody UserPO po) {
        return userService.login(po);
    }

    /**
     * TODO 发送邮箱验证码
     */
    @PostMapping("/sendCode")
    public R sendCode(@RequestBody UserEntity user) {
        return userService.sendCode(user);
    }

    /**
     * TODO 注册
     */
    @PostMapping("/register")
    public R register(@RequestBody UserPO po) {
        return userService.register(po);
    }

    /**
     * TODO 获取登录的用户信息
     */
    @PostMapping("/info")
    public R info(){
        return userService.info();
    }

    /**
     * TODO 注销
     */
    @DeleteMapping("/")
    public R logoff(){
        return userService.logoff();
    }

    /**
     * TODO 改
     */
    @PutMapping("/")
    public R update(@RequestBody UserEntity user){
		userService.updateById(user);
        return R.ok();
    }

    /**
     * TODO 查
     */
    @GetMapping("/{id}")
    public R info(@PathVariable("id") Long id){
        return userService.info(id);
    }

    /**
     * TODO 关注/取关 别人
     */
    @PostMapping("/follow")
    public R followUser(@RequestBody FollowPO po){
        return userService.followUser(po);
    }


    /**
     * TODO 列表
     */
    @GetMapping("/list")
    public R list(@RequestParam Map<String, Object> params){
        return userService.list(params);
    }

}
