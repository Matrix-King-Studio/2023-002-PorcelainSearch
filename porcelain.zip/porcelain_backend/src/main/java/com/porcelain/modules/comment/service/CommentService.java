package com.porcelain.modules.comment.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.porcelain.common.utils.PageUtils;
import com.porcelain.common.utils.R;
import com.porcelain.modules.comment.entity.CommentEntity;
import com.porcelain.modules.comment.po.LovePO;

import java.util.List;
import java.util.Map;

/**
 * TODO 评论
 */
public interface CommentService extends IService<CommentEntity> {


    List<CommentEntity> list(Map<String, Object> params);

    R add(CommentEntity comment);

    R del(CommentEntity comment);

    R love(LovePO po);
}

