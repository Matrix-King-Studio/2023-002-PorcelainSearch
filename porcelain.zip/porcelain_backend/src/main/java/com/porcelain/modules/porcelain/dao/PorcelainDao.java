package com.porcelain.modules.porcelain.dao;

import com.porcelain.modules.porcelain.entity.PorcelainEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * TODO 瓷器
 */
@Mapper
public interface PorcelainDao extends BaseMapper<PorcelainEntity> {
	
}
