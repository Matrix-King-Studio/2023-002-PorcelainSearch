package com.porcelain.modules.article.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.porcelain.common.utils.PageUtils;
import com.porcelain.common.utils.R;
import com.porcelain.modules.article.entity.ArticleEntity;
import com.porcelain.modules.article.po.LovePO;

import java.util.List;
import java.util.Map;

/**
 * TODO 文章
 */
public interface ArticleService extends IService<ArticleEntity> {
    R publish(ArticleEntity article);

    R del(Long[] articleIdList);

    R info(Long id);

    List<ArticleEntity> list(Map<String, Object> params);

    R love(LovePO po);
}

