package com.porcelain.modules.user.po;

import lombok.Data;

/**
 * @description: TODO
 * @author nuo
 * @date 2023/3/4 13:15
 * @version 1.0
 */
@Data
public class UserPO {

    private String username;
    private String email;
    private String password;
    private String code;

}
