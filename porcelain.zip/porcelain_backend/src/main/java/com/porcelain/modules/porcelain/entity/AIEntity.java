package com.porcelain.modules.porcelain.entity;

import lombok.Data;

import java.util.List;

/**
 * @description: TODO
 * @author nuo
 * @date 2023/3/8 1:26
 * @version 1.0
 */
@Data
public class AIEntity {

    private List<AI> result;
    private Long log_id;
    private Boolean has_more;
    private Integer result_num;

    @Data
    public class AI {
        private Object brief;
        private float score;
        private String cont_sign;
    }

}
