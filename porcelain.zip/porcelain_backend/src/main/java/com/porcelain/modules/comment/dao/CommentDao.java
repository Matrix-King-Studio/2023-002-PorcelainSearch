package com.porcelain.modules.comment.dao;

import com.porcelain.modules.comment.entity.CommentEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * TODO 评论
 */
@Mapper
public interface CommentDao extends BaseMapper<CommentEntity> {
	
}
