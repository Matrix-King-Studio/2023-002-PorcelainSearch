package com.porcelain.modules.user.interceptor;


import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.porcelain.modules.sys.entity.SysUserTokenEntity;
import com.porcelain.modules.sys.service.SysUserTokenService;
import com.porcelain.modules.user.threadlocal.UserThreadLocal;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static com.porcelain.common.utils.ShiroUtils.getUserId;

/**
 * @description: TODO 获取当前登陆信息
 * @author nuo
 * @date 2022/11/21 12:40
 * @version 1.0
 */
@Component
@Slf4j
public class UserInterceptor implements HandlerInterceptor {

    @Autowired
    private UserThreadLocal userThreadLocal;

    @Autowired
    private SysUserTokenService sysUserTokenService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //从header中获取token
        String token = request.getHeader("token");
        if (StrUtil.isNotBlank(token)) {
            SysUserTokenEntity tokenEntity = sysUserTokenService.getOne(
                    new LambdaQueryWrapper<SysUserTokenEntity>()
                            .eq(SysUserTokenEntity::getToken, token)
                            .eq(SysUserTokenEntity::getIdentity, 1)
            );
            if (!ObjectUtil.isEmpty(tokenEntity)) {
                userThreadLocal.set(tokenEntity.getUserId());
            }
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        HandlerInterceptor.super.postHandle(request, response, handler, modelAndView);
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        userThreadLocal.remove();
        HandlerInterceptor.super.afterCompletion(request, response, handler, ex);
    }

}
