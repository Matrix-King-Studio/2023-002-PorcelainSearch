package com.porcelain.modules.common.cos;

import com.porcelain.common.utils.R;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;



/**
 * @description: TODO Test 测试用
 * @author nuo
 * @date 2022/10/10 1:28
 * @version 1.0
 */

@Api(tags = {"腾讯云"})
@RestController
@RequestMapping("storage/cos")
@CrossOrigin
public class COSController {

    @Autowired
    COSService cosService;

    @PostMapping("/upload")
    @ApiOperation("上传...")
    public R upload(@RequestParam("file") MultipartFile[] fileArr) {
        return cosService.upload(fileArr);
    }

    @PostMapping("/download")
    @ApiOperation("下载...")
    public R download(@RequestBody FilePO po) {
        return cosService.download(po);
    }

    @PostMapping("/del")
    @ApiOperation("删除...")
    public R del(@RequestBody FilePO po) {
        return cosService.del(po.getKey());
    }

}
