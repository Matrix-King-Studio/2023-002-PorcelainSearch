package com.porcelain.modules.user.dao;

import com.porcelain.modules.user.entity.UserEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * TODO 用户
 */
@Mapper
public interface UserDao extends BaseMapper<UserEntity> {
	
}
