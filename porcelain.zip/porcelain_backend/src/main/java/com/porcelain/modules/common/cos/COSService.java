package com.porcelain.modules.common.cos;

import com.porcelain.common.utils.R;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


@Service("cosService")
public interface COSService {

    /**
     * @description: 文件上传
     * @param fileArr 文件数组
     * @return com.nuo.backend.common.utils.R
     * @date: 2022/10/10 2:38
     */
    R upload(MultipartFile[] fileArr);


    /**
     * @return com.nuo.backend.common.utils.R
     * @description: 文件下载
     * @date: 2022/10/10 16:44
     */
    R download(FilePO po);


    /**
     * @description: 文件删除
     * @param key  : 文件唯一 id
     * @return com.nuo.backend.common.utils.R
     * @date: 2022/10/10 2:39
     */
    R del(String key);

}
