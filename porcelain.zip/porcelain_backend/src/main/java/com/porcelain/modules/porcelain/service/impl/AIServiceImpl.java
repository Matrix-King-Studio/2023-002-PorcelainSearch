package com.porcelain.modules.porcelain.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.porcelain.common.utils.HttpUtil;
import com.porcelain.common.utils.R;
import com.porcelain.config.ImageConfig;
import com.porcelain.modules.porcelain.entity.AIEntity;
import com.porcelain.modules.porcelain.po.AddOrPutPO;
import com.porcelain.modules.porcelain.po.UrlPO;
import com.porcelain.modules.porcelain.service.AIService;
import com.porcelain.modules.porcelain.service.PorcelainService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

@Slf4j
@Service("aiService")
public class AIServiceImpl implements AIService {

    @Autowired
    private PorcelainService porcelainService;

    @Autowired
    private ImageConfig imageConfig;

    @Override
    public void add(AddOrPutPO po) {
        String url = "https://aip.baidubce.com/rest/2.0/image-classify/v1/realtime_search/similar/add";
        try {
            String param = "url=" + po.getImageUrl() + "&brief=" + JSONObject.toJSONString(po.getBrief()) + "&tags=" + "1,1";
            HttpUtil.post(url, getToken(), param);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    @Override
    public void del(UrlPO po) {
        String url = "https://aip.baidubce.com/rest/2.0/image-classify/v1/realtime_search/similar/delete";
        try {
            String data = "url=" + po.getUrl();
            HttpUtil.post(url, getToken(), data);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    @Override
    public void del(String imgUrl) {
        String url = "https://aip.baidubce.com/rest/2.0/image-classify/v1/realtime_search/similar/delete";
        try {
            String data = "url=" + imgUrl;
            HttpUtil.post(url, getToken(), data);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    @Override
    public void put(AddOrPutPO po) {
        String url = "https://aip.baidubce.com/rest/2.0/image-classify/v1/realtime_search/similar/update";
        try {
            String data = "brief=" + JSONObject.toJSONString(po.getBrief()) + "&url=" + po.getImageUrl() + "&tags=" + "1,1";
            HttpUtil.post(url, getToken(), data);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    @Override
    public R check(UrlPO po) {
        String url = "https://aip.baidubce.com/rest/2.0/image-classify/v1/realtime_search/similar/search";
        try {
            String data = "url=" + po.getUrl();
            String resultStr = HttpUtil.post(url, getToken(), data);
            AIEntity aiEntity = JSONObject.parseObject(resultStr, AIEntity.class);
            AIEntity.AI ai = aiEntity.getResult().get(0);
            return R.ok().put("res", porcelainService
                    .getById(Long.parseLong(ai.getBrief().toString()))
            );
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return R.error();
    }


    private String getToken() {
        // 获取token地址
        String authHost = "https://aip.baidubce.com/oauth/2.0/token?";
        String getAccessTokenUrl = authHost
                // 1. grant_type为固定参数
                + "grant_type=client_credentials"
                // 2. 官网获取的 API Key
                + "&client_id=" + imageConfig.getApiKey()
                // 3. 官网获取的 Secret Key
                + "&client_secret=" + imageConfig.getSecretKey();
        try {
            URL realUrl = new URL(getAccessTokenUrl);
            // 打开和URL之间的连接
            HttpURLConnection connection = (HttpURLConnection) realUrl.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();
            // 获取所有响应头字段
            // 定义 BufferedReader输入流来读取URL的响应
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String result = "";
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
            JSONObject jsonObject = JSONObject.parseObject(result);
            return jsonObject.getString("access_token");
        } catch (Exception e) {
            log.error("获取图形库 token 失败！");
        }
        return null;
    }

}
