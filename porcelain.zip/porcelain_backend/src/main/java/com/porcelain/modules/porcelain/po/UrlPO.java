package com.porcelain.modules.porcelain.po;

import lombok.Data;

/**
 * @description: TODO
 * @author nuo
 * @date 2023/3/7 19:40
 * @version 1.0
 */
@Data
public class UrlPO {
    private String url;
}
