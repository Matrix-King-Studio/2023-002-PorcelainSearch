package com.porcelain.modules.user.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.porcelain.common.utils.*;
import com.porcelain.modules.article.service.ArticleService;
import com.porcelain.modules.sys.service.SysUserTokenService;
import com.porcelain.modules.user.dao.UserDao;
import com.porcelain.modules.user.entity.UserEntity;
import com.porcelain.modules.user.po.FollowPO;
import com.porcelain.modules.user.po.UserPO;
import com.porcelain.modules.user.service.UserService;
import com.porcelain.modules.user.threadlocal.UserThreadLocal;
import org.apache.shiro.crypto.hash.Sha256Hash;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;


@Service("userService")
public class UserServiceImpl extends ServiceImpl<UserDao, UserEntity> implements UserService {

    @Autowired
    private SysUserTokenService sysUserTokenService;

    @Autowired
    private EmailUtil emailUtil;

    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private UserThreadLocal userThreadLocal;

    @Autowired
    private ArticleService articleService;

    @Override
    public R login(UserPO po) {
        UserEntity one = getOne(new LambdaQueryWrapper<UserEntity>()
                .eq(UserEntity::getEmail, po.getEmail())
                .eq(UserEntity::getPassword, new Sha256Hash(po.getPassword()).toHex())
        );
        if (one == null) {
            return R.error(403, "邮箱或密码输入有误, 请重新输入...");
        }
        return sysUserTokenService.createToken(one.getId(), 1);
    }

    @Override
    public R sendCode(UserEntity user) {
        if (redisUtil.get(RedisKeys.getEmailKey(user.getEmail())) != null) {
            return R.error("验证码已发送, 请注意查收...");
        }
        String code = CharUtil.getRandomString(6);
        redisUtil.setEx(RedisKeys.getEmailKey(user.getEmail()), code, 5, TimeUnit.MINUTES);
        emailUtil.send(user.getEmail(), "瓷器系统邮箱验证码", "您收到的邮箱验证码为: " + code + ", 有效时常五分钟...");
        return R.ok();
    }

    @Override
    public R register(UserPO po) {
        if (!po.getCode().equals(redisUtil.get(RedisKeys.getEmailKey(po.getEmail())))) {
            return R.error("验证码输入有误...");
        }
        if (getOne(new LambdaQueryWrapper<UserEntity>().eq(UserEntity::getEmail, po.getEmail())) != null) {
            return R.error("该邮箱已注册...");
        }
        redisUtil.delete(RedisKeys.getEmailKey(po.getEmail()));
        UserEntity user = new UserEntity().setEmail(po.getEmail()).setPassword(new Sha256Hash(po.getPassword()).toHex()).setUsername(po.getUsername());
        save(user);

        redisUtil.set(RedisKeys.getUserVisitCntKey(user.getId()), 0);
        redisUtil.set(RedisKeys.getUserLoveCntKey(user.getId()), 0);
        return R.ok();
    }

    @Override
    public UserEntity getById(Serializable id) {
        return super.getById(id)
                .setFollowCnt(redisUtil.sSize(RedisKeys.getUserFollowKey(id)))
                .setFanCnt(redisUtil.sSize(RedisKeys.getUserFanKey(id)))
                .setVisitCnt(Long.parseLong(redisUtil.get(RedisKeys.getUserVisitCntKey(id)).toString()))
                .setLoveCnt(Long.parseLong(redisUtil.get(RedisKeys.getUserLoveCntKey(id)).toString()))
                .setFollowStatus(userThreadLocal.get() == null ? 0 : (userThreadLocal.get().equals(id) || redisUtil.sIsMember(RedisKeys.getUserFollowKey(userThreadLocal.get()), id) ? 1 : 0))
                .setArticleList(articleService.list(new HashMap<String, Object>() {{
                    put("userId", id);
                }}));
    }

    @Override
    public R info() {
        return R.ok().put("user", getById(userThreadLocal.get()));
    }

    @Override
    public R info(Long id) {
        redisUtil.incr(RedisKeys.getUserVisitCntKey(id));
        return R.ok().put("user", getById(id));
    }

    @Override
    public R logoff() {
        removeById(userThreadLocal.get());
        return R.ok();
    }

    @Override
    public R list(Map<String, Object> params) {
        return R.ok().put(
                "list",
                list(new LambdaQueryWrapper<UserEntity>()
                        .in("follow".equals(params.get("type")), UserEntity::getId, redisUtil.sMembers(RedisKeys.getUserFollowKey((Serializable) params.get("userId"))))
                        .in("fan".equals(params.get("type")), UserEntity::getId, redisUtil.sMembers(RedisKeys.getUserFanKey((Serializable) params.get("userId"))))
                        .and(StrUtil.isNotBlank((String) params.get("key")),
                                i -> i.like(UserEntity::getUsername, params.get("key"))
                                        .or()
                                        .like(UserEntity::getEmail, params.get("key"))
                        )
                )
                        .stream()
                        .map(user -> user.setFollowStatus(userThreadLocal.get() == null ? 0 :
                                (userThreadLocal.get().equals(user.getId()) || redisUtil.sIsMember(RedisKeys.getUserFollowKey(userThreadLocal.get()), user.getId()) ? 1 : 0))
                        ).collect(Collectors.toList())
        );
    }

    @Override
    public R followUser(FollowPO po) {
        if (po.getStatus() == 0) {
            redisUtil.sAdd(RedisKeys.getUserFollowKey(userThreadLocal.get()), po.getId());
            redisUtil.sAdd(RedisKeys.getUserFanKey(po.getId()), userThreadLocal.get());
            return R.ok("关注成功...");
        } else {
            redisUtil.sRemove(RedisKeys.getUserFollowKey(userThreadLocal.get()), po.getId());
            redisUtil.sRemove(RedisKeys.getUserFanKey(po.getId()), userThreadLocal.get());
            return R.ok("取关成功...");
        }
    }


}
