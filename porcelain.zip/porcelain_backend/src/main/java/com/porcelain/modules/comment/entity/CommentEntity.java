package com.porcelain.modules.comment.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * TODO 评论
 */
@Data
@TableName("comment")
@Accessors(chain = true)
public class CommentEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	@TableId
	private Long id;
	/**
	 * 帖子 id
	 */
	private Long articleId;
	/**
	 * 父评论 id
	 */
	private Long parentId;
	/**
	 * 父评论的用户 id
	 */
	@TableField(exist = false)
	private Long parentUserId;
	/**
	 * 父评论的用户名
	 */
	@TableField(exist = false)
	private String parentUsername;
	/**
	 * 父评论的用户头像
	 */
	@TableField(exist = false)
	private String parentAvatar;
	/**
	 * 发布评论的用户 id
	 */
	private Long userId;
	/**
	 * 发布评论的用户名
	 */
	@TableField(exist = false)
	private String username;
	/**
	 * 发布评论的用户头像
	 */
	@TableField(exist = false)
	private String avatar;
	/**
	 * 评论内容
	 */
	private String content;
	/**
	 * 评论是否点赞
	 */
	@TableField(exist = false)
	private Integer loveStatus;

	/**
	 * 评论的点赞数
	 */
	@TableField(exist = false)
	private Long loveCnt;
	/**
	 * 创建日期
	 */
	private Date gmtCreate;
	/**
	 * 修改日期
	 */
	private Date gmtModified;
	/**
	 * 逻辑删除
	 */
	private Integer isDeleted;

}
