package com.porcelain.modules.comment.po;

import lombok.Data;

/**
 * @description: TODO
 * @author nuo
 * @date 2023/3/6 1:23
 * @version 1.0
 */
@Data
public class LovePO {
    /**
     * 评论 id
     */
    private Long id;
    /**
     * 评论发布者的 id
     */
    private Long userId;
    /**
     * 点赞状态(0: 未点赞 | 1: 已点赞)
     */
    private Integer status;
}
