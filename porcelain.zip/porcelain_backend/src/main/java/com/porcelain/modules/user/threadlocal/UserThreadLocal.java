package com.porcelain.modules.user.threadlocal;

import com.porcelain.modules.user.entity.UserEntity;
import org.springframework.stereotype.Component;

/**
 * @description: TODO
 * @author nuo
 * @date 2023/3/4 14:09
 * @version 1.0
 */
@Component
public class UserThreadLocal {

    private static final ThreadLocal<Long> threadLocal = new ThreadLocal<>();

    public void set(Long userId) {
        threadLocal.set(userId);
    }

    public Long get() {
        return threadLocal.get();
    }

    public void remove() {
        threadLocal.remove();
    }

}
