package com.porcelain.modules.porcelain.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * TODO 瓷器
 */
@Data
@TableName("porcelain")
public class PorcelainEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 瓷器 id
	 */
	@TableId
	private Long id;
	/**
	 * 瓷器标题
	 */
	private String title;
	/**
	 * 类型
	 */
	private String type;
	/**
	 * 朝代
	 */
	private String dynasty;
	/**
	 * 相关图片
	 */
	private String url;
	/**
	 * 介绍
	 */
	private String introduction;
	/**
	 * 细节描述
	 */
	private String detail;
	/**
	 * 创建日期
	 */
	private Date gmtCreate;
	/**
	 * 修改日期
	 */
	private Date gmtModified;
	/**
	 * 逻辑删除
	 */
	private Integer isDeleted;

}
