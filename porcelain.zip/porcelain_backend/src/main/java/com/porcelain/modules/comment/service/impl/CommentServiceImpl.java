package com.porcelain.modules.comment.service.impl;

import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.porcelain.common.utils.R;
import com.porcelain.common.utils.RedisKeys;
import com.porcelain.common.utils.RedisUtil;
import com.porcelain.modules.article.service.ArticleService;
import com.porcelain.modules.comment.dao.CommentDao;
import com.porcelain.modules.comment.entity.CommentEntity;
import com.porcelain.modules.comment.po.LovePO;
import com.porcelain.modules.comment.service.CommentService;
import com.porcelain.modules.user.entity.UserEntity;
import com.porcelain.modules.user.service.UserService;
import com.porcelain.modules.user.threadlocal.UserThreadLocal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;


@Service("commentService")
public class CommentServiceImpl extends ServiceImpl<CommentDao, CommentEntity> implements CommentService {

    @Autowired
    private UserThreadLocal userThreadLocal;

    @Autowired
    private ArticleService articleService;

    @Autowired
    private UserService userService;

    @Autowired
    private RedisUtil redisUtil;

    @Override
    public R add(CommentEntity comment) {
        save(comment.setUserId(userThreadLocal.get()));
        return R.ok("评论成功...");
    }

    @Override
    public R del(CommentEntity comment) {
        if (comment.getUserId().equals(userThreadLocal.get()) || (comment.getArticleId() != null && articleService.getById(comment.getArticleId()).getUserId().equals(userThreadLocal.get()))) {
            List<CommentEntity> list = new ArrayList<>(Arrays.asList(comment));
            // TODO 获取所有该评论的子评论
            getChildCommentList(getAll(comment.getArticleId()), list, comment.getId());
            // TODO 删除所有子评论相关信息
            removeByIds(list.stream().map(CommentEntity::getId).collect(Collectors.toSet()));
            list.stream().forEach(i -> redisUtil.delete(RedisKeys.getCommentLoveKey(i.getId())));
            return R.ok("删除成功...");
        }
        return R.error("权限不足...");
    }

    @Override
    public R love(LovePO po) {
        if (po.getStatus() == 0) {
            redisUtil.sAdd(RedisKeys.getCommentLoveKey(po.getId()), userThreadLocal.get());
            return R.ok("点赞成功...");
        } else {
            redisUtil.sRemove(RedisKeys.getCommentLoveKey(po.getId()), userThreadLocal.get());
            return R.ok("取消点赞...");
        }
    }

    @Override
    public List<CommentEntity> list(Map<String, Object> params) {

        // TODO 获取全部评论
        Map<Long, CommentEntity> all = getAll(Long.parseLong(params.get("articleId").toString()));

        if (ObjectUtil.isEmpty(all)) {
            return null;
        }

        // TODO 获取所有评论文章的用户信息
        Map<Long, UserEntity> userMap = userService.listByIds(
                        all.values().stream().map(CommentEntity::getUserId).collect(Collectors.toSet())
                ).stream()
                .collect(Collectors.toMap(UserEntity::getId, Function.identity()));

        // TODO 封装相关信息
        if ("parent".equals(params.get("type").toString())) {
            // TODO 获取父评论列表
            List<CommentEntity> parentCommentList = all.values().stream()
                    .filter(user -> user.getParentId() == null)
                    .collect(Collectors.toList());
            parentCommentList.stream().forEach(parentComment -> parentComment
                    .setAvatar(userMap.get(parentComment.getUserId()).getAvatar())
                    .setUsername(userMap.get(parentComment.getUserId()).getUsername())
                    .setLoveCnt(redisUtil.sSize(RedisKeys.getCommentLoveKey(parentComment.getId())))
                    .setLoveStatus(
                            userThreadLocal.get() == null ? 0 :
                                    (redisUtil.sIsMember(RedisKeys.getCommentLoveKey(parentComment.getId()), userThreadLocal.get()) ? 1 : 0)
                    ));
            return parentCommentList;
        } else {
            // TODO 获取子评论
            List<CommentEntity> childCommentList = new ArrayList<>();
            getChildCommentList(all, childCommentList, Long.parseLong(params.get("parentId").toString()));

            childCommentList.stream().forEach(childComment -> childComment
                    .setAvatar(userMap.get(childComment.getUserId()).getAvatar())
                    .setUsername(userMap.get(childComment.getUserId()).getUsername())
                    .setParentUserId(all.get(childComment.getParentId()).getUserId())
                    .setParentAvatar(userMap.get(all.get(childComment.getParentId()).getUserId()).getAvatar())
                    .setParentUsername(userMap.get(all.get(childComment.getParentId()).getUserId()).getUsername())
                    .setLoveCnt(redisUtil.sSize(RedisKeys.getCommentLoveKey(childComment.getId())))
                    .setLoveStatus(
                            userThreadLocal.get() == null ? 0 :
                                    (redisUtil.sIsMember(RedisKeys.getCommentLoveKey(childComment.getId()), userThreadLocal.get()) ? 1 : 0)
                    ));

            return childCommentList;
        }

    }


    private void getChildCommentList(Map<Long, CommentEntity> all, List<CommentEntity> childCommentList, Long parentCommentId) {
        if (parentCommentId == null) {
            return;
        }
        List<CommentEntity> list = all.values().stream().filter(comment -> parentCommentId.equals(comment.getParentId())).collect(Collectors.toList());
        childCommentList.addAll(list);
        list.forEach(comment -> getChildCommentList(all, childCommentList, comment.getId()));
    }

    private Map<Long, CommentEntity> getAll(Long articleId) {
        return list(new LambdaQueryWrapper<CommentEntity>()
                .eq(CommentEntity::getArticleId, articleId)
                .orderByDesc(CommentEntity::getGmtCreate)
        ).stream().collect(Collectors.toMap(CommentEntity::getId, Function.identity()));
    }
}