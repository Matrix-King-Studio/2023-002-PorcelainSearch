package com.porcelain.modules.porcelain.po;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @description: TODO
 * @author nuo
 * @date 2023/3/7 19:49
 * @version 1.0
 */
@Data
@Accessors(chain = true)
public class AddOrPutPO {
    private String imageUrl;
    private Object brief;
}
