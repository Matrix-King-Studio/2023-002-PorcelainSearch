package com.porcelain.modules.article.service.impl;

import cn.hutool.core.util.ObjectUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.porcelain.common.utils.R;
import com.porcelain.common.utils.RedisKeys;
import com.porcelain.common.utils.RedisUtil;
import com.porcelain.modules.article.dao.ArticleDao;
import com.porcelain.modules.article.entity.ArticleEntity;
import com.porcelain.modules.article.po.LovePO;
import com.porcelain.modules.article.service.ArticleService;
import com.porcelain.modules.comment.entity.CommentEntity;
import com.porcelain.modules.comment.service.CommentService;
import com.porcelain.modules.user.entity.UserEntity;
import com.porcelain.modules.user.service.UserService;
import com.porcelain.modules.user.threadlocal.UserThreadLocal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;


@Service("articleService")
public class ArticleServiceImpl extends ServiceImpl<ArticleDao, ArticleEntity> implements ArticleService {

    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private UserThreadLocal userThreadLocal;

    @Lazy
    @Autowired
    private CommentService commentService;

    @Lazy
    @Autowired
    private UserService userService;

    @Override
    public R publish(ArticleEntity article) {
        saveOrUpdate(article.setUserId(userThreadLocal.get()));
        return R.ok("发布成功...");
    }

    @Override
    public R del(Long[] articleIdList) {
        if (!ObjectUtil.isEmpty(articleIdList)) {
            // TODO 删除文章评论
            Set<Long> commentIdSet = commentService.list(new LambdaQueryWrapper<CommentEntity>().in(CommentEntity::getArticleId, articleIdList).eq(CommentEntity::getUserId, userThreadLocal.get())).stream().map(CommentEntity::getId).collect(Collectors.toSet());
            if (!ObjectUtil.isEmpty(commentIdSet)) {
                commentService.removeByIds(commentIdSet);
                commentIdSet.forEach(i -> redisUtil.delete(RedisKeys.getCommentLoveKey(i)));
            }
            // TODO 删除文章
            removeByIds(Arrays.asList(articleIdList));
            Arrays.stream(articleIdList).forEach(i -> redisUtil.delete(RedisKeys.getArticleLoveKey(i)));
        }
        return R.ok("删除成功...");
    }

    @Override
    public R info(Long id) {
        ArticleEntity article = getById(id);

        if (article == null) {
            return R.error(404, "文章不存在...");
        }

        return R.ok().put("article", article
                .setLoveStatus(userThreadLocal.get() == null ? 0 : (redisUtil.sIsMember(RedisKeys.getArticleLoveKey(id), userThreadLocal.get()) ? 1 : 0))
                .setAvatar(userService.getById(article.getUserId()).getAvatar())
                .setCommentCnt(commentService.count(new LambdaQueryWrapper<CommentEntity>().eq(CommentEntity::getArticleId, id)))
                .setFollowStatus(userThreadLocal.get() == null ? 0 : (redisUtil.sIsMember(RedisKeys.getUserFollowKey(userThreadLocal.get()), article.getUserId()) ? 1 : 0))
                .setParentCommentList(commentService.list(new HashMap<String, Object>() {{
                    put("articleId", id);
                    put("type", "parent");
                }}))
        );
    }

    @Override
    public List<ArticleEntity> list(Map<String, Object> params) {
        List<ArticleEntity> list = list(new LambdaQueryWrapper<ArticleEntity>()
                .eq(ObjectUtil.isNotEmpty(params.get("userId")), ArticleEntity::getUserId, params.get("userId"))
                .like(ObjectUtil.isNotEmpty(params.get("key")), ArticleEntity::getTitle, params.get("key"))
                .eq(ObjectUtil.isNotEmpty(params.get("type")), ArticleEntity::getType, params.get("type"))
                .orderByDesc(ArticleEntity::getGmtCreate)
        );
        if (ObjectUtil.isNotEmpty(list)) {
            Map<Long, UserEntity> userMap = userService
                    .listByIds(list.stream().map(ArticleEntity::getUserId).collect(Collectors.toSet()))
                    .stream()
                    .collect(Collectors.toMap(UserEntity::getId, Function.identity()));

            return list.stream().map(article ->
                    article.setLoveStatus(userThreadLocal.get() == null ? 0 : (redisUtil.sIsMember(RedisKeys.getArticleLoveKey(article.getId()), userThreadLocal.get()) ? 1 : 0))
                            .setLoveCnt(userThreadLocal.get() == null ? 0 : (redisUtil.sSize(RedisKeys.getArticleLoveKey(article.getId()))))
                            .setUsername(userMap.get(article.getUserId()).getUsername())
                            .setAvatar(userMap.get(article.getUserId()).getAvatar())
                            .setCommentCnt(commentService.count(new LambdaQueryWrapper<CommentEntity>().eq(CommentEntity::getArticleId, article.getId())))
                            .setFollowStatus(userThreadLocal.get() == null ? 0 : (redisUtil.sIsMember(RedisKeys.getUserFollowKey(userThreadLocal.get()), article.getUserId()) ? 1 : 0))
            ).collect(Collectors.toList());
        }
        return list;
    }

    @Override
    public R love(LovePO po) {
        if (po.getStatus() == 0) {
            redisUtil.sAdd(RedisKeys.getArticleLoveKey(po.getId()), userThreadLocal.get());
            redisUtil.incr(RedisKeys.getUserLoveCntKey(po.getUserId()));
            return R.ok("点赞成功...");
        } else {
            redisUtil.sRemove(RedisKeys.getArticleLoveKey(po.getId()), userThreadLocal.get());
            redisUtil.decr(RedisKeys.getUserLoveCntKey(po.getUserId()));
            return R.ok("取消点赞...");
        }
    }

}