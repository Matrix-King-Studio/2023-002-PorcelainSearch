package com.porcelain.modules.porcelain.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.porcelain.common.utils.PageUtils;
import com.porcelain.common.utils.R;
import com.porcelain.modules.porcelain.entity.PorcelainEntity;

import java.util.List;
import java.util.Map;

/**
 * TODO 瓷器
 */
public interface PorcelainService extends IService<PorcelainEntity> {

    R add(PorcelainEntity porcelain);

    R del(List<PorcelainEntity> porcelainList);

    R put(PorcelainEntity porcelain);

    R list(Map<String, Object> params);

    R dynastyList();

}

