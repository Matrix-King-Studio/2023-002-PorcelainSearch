package com.porcelain.modules.common.cos;

import lombok.Data;

/**
 * @description: TODO
 * @author nuo
 * @date 2023/1/12 17:43
 * @version 1.0
 */
@Data
public class FilePO {

    /**
     * 文件 id eg.'881f853eb9e34c0c8721b464c380f236.jpg'
     */
    private String key;
    /**
     * 文件的保存路径 eg.'F:\\'
     */
    private String path;
    /**
     * 文件名 eg.'老实巴交.jpg'
     */
    private String fileName;
}
