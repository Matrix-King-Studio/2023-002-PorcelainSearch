<template>
	<view>
		<view class="topSearch">
			<u-search placeholder="请输入要搜索的内容" @search="search" @custom="custom" showAction v-model="key" shape="round"
				:clearabled="true" height="25" action-style></u-search>
		</view>
		<view class="classifyNav">
			<u-tabs :list="list" :is-scroll="false" :current="current" bar-width="50" active-color="orange"
				@change="change" :activeStyle="{
            color: '#303133',
            fontWeight: 'bold',
            transform: 'scale(1.05)'
        }" :inactiveStyle="{
            color: '#606266',
            transform: 'scale(1)'
        }" itemStyle="padding-left: 15px; padding-right: 15px; height: 34px;" lineColor="#fbc02d">
			</u-tabs>
			<view v-for="porcelain in porcelainList">
				<view class="porcelainName">{{porcelain.title}}</view>
				<view class="backgroundBox" @click="introduce(porcelain.id)">
					<image :src="porcelain.url" mode="aspectFit"></image>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				key: '',
				list: [],
				current: 0,
				porcelainList: []
			}
		},
		onLoad() {
			this.getDynastyList()
		},
		methods: {
			change(index) {
				this.current = index.index;
				this.getPorcelainList();
				this.getDynastyList()
			},
			introduce(id) {
				uni.navigateTo({
					url: '/pages/introduce/introduce?id=' + id
				})
			},
			search(value) {
				this.getPorcelainList();
			},
			custom(value) {
				this.getPorcelainList();
			},
			getPorcelainList() {
				this.$request({
					url: '/porcelain/list',
					method: 'GET',
					data: {
						key: this.key,
						name: this.list[this.current].name
					}
				}).then(res => {
					console.log(res.data);
					if (res.data.code != 0) {
						uni.showToast({
							title: '失败提示',
							icon: 'error',
							duration: 2000
						})
					} else {
						this.porcelainList = res.data.list
						console.log("成功")
					}
				});

			},
			getDynastyList() {
				this.$request({
					url: '/porcelain/dynastyList',
					method: 'GET'
				}).then(res => {
					console.log(res.data);
					if (res.data.code != 0) {
						uni.showToast({
							title: '失败提示',
							icon: 'error',
							duration: 2000
						})
					} else {
						this.list = res.data.dynastyList
						this.getPorcelainList(0);
						console.log("成功")
					}
				});

			},

		}
	}
</script>

<style lang="less" scoped>
	/deep/.u-search {
		width: 85%;
		margin: 15rpx auto !important;

		.u-search__action.data-v-1a326067 {
			width: 100rpx;
			Z height: 50rpx;
			border: 2rpx solid #eee;
			border-radius: 15rpx;
			line-height: 50rpx;
			background-color: #d3a180;
			color: #fff;
		}
	}

	/deep/.u-tabs__wrapper__nav {
		// border: 5rpx solid #eee;
	}

	.classifyNav {
		.porcelainName {
			position: absolute;
			background-color: #fff;
			font-size: 25rpx;
			color: #916f58;
			margin-top: 15rpx;
			margin-left: 25rpx;
			padding: 2rpx 20rpx;
			border-radius: 25rpx;
		}

		.backgroundBox {
			width: 97%;
			height: 500rpx;
			margin: 6rpx auto;
			background-color: #916f58;
			// background-color: #fbc02d;

			image {
				width: 100%;
				height: 100%;
			}
		}
	}
</style>
