<template>
	<view>
		<view class="talkArticle">

			<!-- 文章 -->
			<view class="userHeader">
				<view class="userPhoto">
					<image :src="author.avatar" mode="aspectFit"></image>
				</view>
				<view class="nameBox">{{author.username}}</view>
			</view>
			<view class="contents">
				<u-read-more ref="uReadMore" :toggle="true" showHeight="100">
					<u-parse :content="article.content" style="font-size: 28rpx; letter-spacing:3rpx" @load="load"></u-parse>
				</u-read-more>
			</view>

			<!-- 评论输入框 -->
			<view class="input-box u-f-ac u-f-jsa">
				<input type="text" confirm-type="发送" v-model="val" placeholder="说点什么吧" @confirm="send"
					:focus="commit" />
				<view class="view-btn">
					<button type="primary" @tap="send">发送</button>
				</view>
			</view>

			<!-- 评论区 -->
			<text>评论区</text>
			<view class="comment" v-for="(parentComment, i) in article.parentCommentList">
				<view class="fatherComment">
					<!-- 父评论头部区域 -->
					<view class="fatherUserHeader">
						<view class="fatherUserHeaderLeft">
							<!-- 父评论用户头像，用户名 -->
							<view class="userPhoto">
								<image :src="parentComment.avatar" mode="aspectFit"></image>
							</view>
							<view class="nameBox">{{parentComment.username}}</view>
						</view>
						<view class="fatherUserHeaderRight">
							<!-- 父评论：回复，点赞 图标按钮 -->
							<view class="funcBts">


								<!-- <text @click="reply()">回复</text> -->
								<view @click="tocommit(parentComment.id)">回复</view>
								<!-- 底部输入框 -->
								<input-box :commit="commit" @submit="send"></input-box>

								<u-icon name="thumb-up" size="40rpx"
									:color="parentComment.loveStatus === 1 ? 'red' : 'u-content-color'"
									@click="love(parentComment.id, parentComment.userId, parentComment.loveStatus)">
								</u-icon>
								<view class="number">{{parentComment.loveCnt}}</view>
							</view>
						</view>
					</view>
					<view class="fatherCommentContent">
						{{parentComment.content}}

						<!-- 子评论 -->
						<view class="childComment"
							v-for="childComment in article.parentCommentList[i].childCommentList">
							<!-- 子评论头部区域 -->
							<view class="childUserHeader">
								<view class="childUserHeaderLeft">
									<!-- 子评论用户头像，用户名 -->
									<view class="userPhoto">
										<image :src="childComment.avatar" mode="aspectFit"></image>
									</view>
									<view class="nameBox">{{childComment.username}}</view>
								</view>
								<view class="childUserHeaderRight">
									<!-- 子评论：回复，点赞 图标按钮 -->
									<view class="funcBts">
										<u-icon name="thumb-up" size="40rpx"
											:color="childComment.loveStatus === 1 ? 'red' : 'u-content-color'"
											@click="love(childComment.id, childComment.userId, childComment.loveStatus)">
										</u-icon>
										<view class="number">{{childComment.loveCnt}}</view>
									</view>
								</view>
							</view>
							<view class="childCommentContent">
								{{childComment.content}}
							</view>
						</view>
					</view>
				</view>

			</view>
		</view>

	</view>
</template>


<script>
	export default {
		data() {
			return {
				article: {},
				author: {},
				val: '',
				commit: ''
			}
		},
		props: ['commit'],
		onLoad() {
			// 模拟后端请求

		},
		methods: {
			load() {
				console.log("============================")
				setTimeout(() => {
					this.article.content,
						// 请注意上方已在组件中添加ref-uReadMore
						this.$nextTick(() => {
							this.$refs.uReadMore.init();
						})
				}, 2000);
			},
			onLoad: function(options) {
				console.log("============================")
				console.log(this);
				this.getArticleMsg(options.id);
				setTimeout(() => {
					this.article.content,
						// 请注意上方已在组件中添加ref-uReadMore
						this.$nextTick(() => {
							console.log(this);
							this.$refs.uReadMore.init();
						})
				}, 2000);
			},
			getArticleMsg(id) {
				this.$request({
					url: '/article/' + id,
					method: 'GET'
				}).then(res => {
					console.log(res.data);
					if (res.data.code != 0) {
						uni.showToast({
							title: '失败提示',
							icon: 'error',
							duration: 2000
						})
					} else {
						console.log(res.data)
						this.article = res.data.article
						this.getAuthorInfo(this.article.userId)
						for (var i = 0; i < this.article.parentCommentList.length; i++) {
							this.getChildCommentList(this.article.parentCommentList[i].id, i);
						}
					}
				});

			},
			getAuthorInfo(id) {
				this.$request({
					url: '/user/' + id,
					method: 'GET'
				}).then(res => {
					console.log(res.data)
					this.author = res.data.user
					// console.log('一: 0 -> 1   -----> (0 + 1) % 2 = 1: ' + (0 + 1) % 2)
					// console.log('二: 1 -> 0   -----> (1 + 1) % 2 = 0: ' + (1 + 1) % 2)
				});
			},
			// parentIndex: 当前评论的父评论在 parentCommentList 中的索引, 如果自己就是父评论, 那么它是没有父评论的, 传 null
			// curIndex: 当前评论的在对应 parentCommentList || childCommentList 中的索引
			love(commentId, userId, loveStatus) {
				this.$request({
					url: '/comment/love',
					method: 'POST',
					data: {
						id: commentId,
						userId: userId,
						status: loveStatus
					}
				}).then(res => {
					console.log(res.data)
					if (res.data.code == 0) {
						this.getArticleMsg(this.article.id);
						// 	if (loveStatus == 0) {
						// 		if (parentIndex == -1) {
						// 			console.log('loveStatus == 0 && parentIndex == null')
						// 			this.article.parentCommentList[curIndex].loveStatus = 1
						// 			this.article.parentCommentList[curIndex].loveCnt++
						// 		} else {
						// 			console.log('loveStatus == 0 && parentIndex != null')
						// 			this.article.parentCommentList[parentIndex].childCommentList[curIndex].loveStatus =
						// 				1
						// 			this.article.parentCommentList[parentIndex].childCommentList[curIndex].loveCnt++
						// 		}
						// 	} else {
						// 		if (parentIndex == -1) {
						// 			this.article.parentCommentList[curIndex].loveStatus = 0
						// 			this.article.parentCommentList[curIndex].loveCnt--
						// 		} else {
						// 			this.article.parentCommentList[parentIndex].childCommentList[curIndex].loveStatus =
						// 				0
						// 			this.article.parentCommentList[parentIndex].childCommentList[curIndex].loveCnt--
						// 		}
						// 	}
					}

				});

			},

			getChildCommentList(parentCommentId, index) {
				this.$request({
					url: '/comment/list?articleId=' + this.article.id + '&parentId=' + parentCommentId +
						'&type=child',
					method: 'GET'
				}).then(res => {
					console.log(res.data)
					this.article.parentCommentList[index].childCommentList = res.data.list
				});
			},

			//键盘弹起
			tocommit(parentId) {
				//通过commit传给子子告诉子用户点击评论区要评论
				this.commit = true;
				//这里的dyid是请求接口的时候用来告诉接口评论或回复的是那一条
				this.parentId = parentId;
				console.log(this.parentId)
			},
			//评论
			submit() {
				if (val != '') {
						this.$request({
							url: '/comment/',
							method: 'POST',
							data: {
								"articleId": this.article.id,
								"parentId": this.parentId,
								"content": this.val
							}
						}).then(res => {
							console.log(res.data)
							this.getArticleMsg(this.article.id);
						});
						this.parentId = ''
						this.val = ''
				} else {
					this.$util.tips("评论文字不能为空")
				}
			},
			send() {
				console.log(this.val)
				this.$request({
					url: '/comment/',
					method: 'POST',
					data: {
						"articleId": this.article.id,
						"parentId": this.parentId,
						"content": this.val
					}
				}).then(res => {
					console.log(res.data)
					this.getArticleMsg(this.article.id);
				});
				this.parentId = '',
				this.val = ''
			}
		}

	}
</script>

<style lang="less" scoped>
	/deep/.u-parse{
		font-size: 23rpx;
	}
	.talkArticle {
		padding-bottom: 120rpx;

		.userHeader {
			display: flex;
			width: 99%;
			height: 90rpx;
			display: flex;

			.userPhoto {
				width: 65rpx;
				height: 65rpx;
				margin-left: 20rpx;
				margin-top: 8rpx;


				image {
					width: 100%;
					height: 100%;
					border-radius: 50%;
					border: 3rpx solid #916f58;
				}
			}

			.nameBox {
				width: 200rpx;
				height: 80rpx;
				margin: 20rpx 0rpx 20rpx 20rpx;
				font-size: 32rpx;
				color: black;
				font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
			}
		}
			.contents{
				font-size: 23rpx;
				width: 90%;
				margin: 0 auto;
			}
		text {
			display: inline-block;
			height: 50rpx;
			font-size: 25rpx;
			line-height: 50rpx;
			margin-top: 25rpx;
			margin-left: 30rpx;
			color: #828084;
		}

		.comment {
			// background-color: pink;
			box-shadow: 1px 1px 1px 1px rgba(0, 0, 0, 0.1);
			margin-top: 5rpx;
			width: 99%;
			// height: 1500rpx;
			padding-bottom: 10rpx;




			.fatherComment {

				.fatherUserHeader {
					display: flex;

					.fatherUserHeaderLeft {
						display: flex;

						.userPhoto {
							width: 65rpx;
							height: 65rpx;
							margin-left: 20rpx;
							margin-top: 8rpx;


							image {
								width: 100%;
								height: 100%;
								border-radius: 50%;
								border: 3rpx solid #916f58;
							}
						}

						.nameBox {
							width: 200rpx;
							height: 80rpx;
							margin: 25rpx 0rpx 20rpx 20rpx;
							font-size: 25rpx;
							color: black;
							font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
						}
					}

					.fatherUserHeaderRight {
						margin-top: 30rpx;
						margin-left: 180rpx;

						.funcBts {
							display: flex;
							justify-content: space-between;
							align-items: center;
							width: 200rpx;

							view {
								display: inline-block;
								margin-top: 0rpx;
								font-size: 25rpx;
							}

							.number {
								font-size: 27rpx;
								margin-left: -35rpx;
							}
						}
					}
				}

				// .fatherCommentContent:nth-last-of-type(1) {
				// 	padding-bottom: 100rpx;
				// }

				.fatherCommentContent {
					width: 82%;
					height: auto;
					font-size: 27rpx;
					margin-left: 105rpx;
					margin-top: -30rpx;
					padding-bottom: 5rpx;
color: #5f6266;


					.childComment {
						background-color: #eee;
						border-radius: 20rpx;

						.childUserHeader {
							display: flex;

							.childUserHeaderLeft {
								display: flex;

								.userPhoto {
									width: 45rpx;
									height: 45rpx;
									margin-left: 20rpx;
									margin-top: 15rpx;


									image {
										width: 100%;
										height: 100%;
										border-radius: 50%;
										border: 3rpx solid #916f58;
									}
								}

								.nameBox {
									width: 200rpx;
									height: 80rpx;
									margin: 20rpx 0rpx 20rpx 20rpx;
									font-size: 22rpx;
									color: black;
									font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
								}
							}

							.childUserHeaderRight {
								width: 150rpx;
								height: 35rpx;
								margin-top: 20rpx;
								margin-left: 100rpx;

								.funcBts {
									display: flex;
									justify-content: space-between;
									align-items: center;

									text {
										display: inline-block;
										margin-top: -2rpx;
										font-size: 18rpx;
									}

									.number {
										font-size: 18rpx;
										margin-left: -40rpx;
									}
								}
							}
						}

						.childCommentContent {
							width: 80%;
							padding-bottom: 10rpx;
							margin-left: 95rpx;
							margin-top: -45rpx;
							font-size: 25rpx;
						}
					}
				}
			}
		}
	}

	.input-box {
		display: flex;
		position: fixed;
		z-index: 9999999;
		bottom: 0;
		left: 0;
		right: 0;
		height: 108rpx;
		box-sizing: border-box;
		border-top: 1px solid rgba(204, 204, 204, .4);
		background-color: #fff;

		input {
			border: 1px solid #EEEEEE;
			border-radius: 25rpx;
			background: #EEEEEE;
			padding-left: 20rpx;
			padding-top: 10rpx;
			padding-bottom: 10rpx;
			// flex: 1;
			margin-left: 30rpx;
			width: 70%;
		}

		.view-btn {
			width: 55px;
			margin-left: 20rpx;

			/deep/button {
				background-color: #d3a180;
				font-size: 14px;
				padding: 1rpx 10rpx !important;
				height: 70rpx;
				line-height: 70rpx;
			}
		}


	}
</style>
