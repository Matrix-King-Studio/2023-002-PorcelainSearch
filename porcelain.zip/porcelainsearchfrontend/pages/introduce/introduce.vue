<template>
	<view class="page">
		<view class="miniPage">
			<image class="bg"
				src="https://demo-1311835527.cos.ap-beijing.myqcloud.com/porcelain%2F/images/introback2.png"
				mode="aspectFill"></image>
			<view class="tittle">{{porcelain.title}}</view>
			<view class="imgBox">
				<image :src="porcelain.url" mode="aspectFit"></image>
				<view class="porcelainDetail">
					<text>{{porcelain.detail}}</text>
				</view>
			</view>
			<text>{{porcelain.title}}</text>
			<view class="introduction">
				{{porcelain.introduction}}
			</view>
		</view>
		<u-divider text="分割线" :dot="true"></u-divider>
	</view>
</template>

<script>
	export default {
		onLoad: function(options) {
			this.getPorcelainInfo(options.id);
		},
		data() {
			return {
				porcelain: {}
			}
		},
		methods: {
			getPorcelainInfo(id) {
				this.$request({
					url: '/porcelain/' + id,
					method: 'GET',
					data: {}
				}).then(res => {
					console.log(res.data);
					if (res.data.code != 0) {
						uni.showToast({
							title: '失败提示',
							icon: 'error',
							duration: 2000
						})
					} else {
						this.porcelain = res.data.porcelain
						console.log("成功")
					}
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	.page {
		position: relative;

		/deep/.u-loading-icon {
			margin-top: 300rpx;
		}

		.miniPage {
			.bg {
				opacity: 0.2;
				z-index: -2;
				width: 100%;
				height: 100%;
				position: fixed;
				top: 0%;
			}

			.tittle {
				display: flex;
				justify-content: space-around;
				color: #404040;
				margin: 40rpx 0 35rpx 0;
				// padding: 15rpx;
				font-family: 'Courier New', Courier, monospace;
				font-weight: 600;
				font-size: 36rpx;
			}

			.imgBox {
				position: relative;
				margin: 0 auto;
				width: 95%;
				height: 550rpx;
				margin-bottom: 50rpx;
				border-radius: 15rpx;
				background-color: #a38069;

				image {
					position: absolute;
					width: 100%;
					height: 100%;
					border-radius: 50rpx !important;
				}

				.porcelainDetail {
					position: absolute;
					width: 100%;
					margin-top: 15rpx;
					margin-left: -40rpx;
					opacity: 0.7;

					text {
						font-size: 23rpx;
						background-color: #fff;
						border-radius: 20rpx;
						padding: 4rpx 12rpx;
						color: #404040;
						position: absolute;
						font-weight: 500;
					}
				}
			}

			text {
				font-size: 26rpx;
				font-weight: 700;
				margin-left: 50rpx;
			}

			.introduction {
				color: #424242;
				width: 650rpx;
				margin: 15rpx auto;
				font-size: 32rpx;
				font-family: 'Courier New', Courier, monospace;
				font-weight: 600;
				line-height: 170%;
				text-indent: 2em
			}
		}


	}
</style>
