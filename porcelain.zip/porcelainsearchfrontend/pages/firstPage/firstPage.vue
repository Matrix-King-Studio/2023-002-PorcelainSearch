<template>
	<view class="page">
		<image class="bg" src="https://demo-1311835527.cos.ap-beijing.myqcloud.com/porcelain%2F/images/firstpage.png"
			mode="aspectFill"></image>
		<image class="logo" src="https://demo-1311835527.cos.ap-beijing.myqcloud.com/porcelain%2F/images/logo02.png"
			mode="aspectFit"></image>
		<u-transition :show="show" mode="slide-down">
			<view class="transition">
				<view class="textStyle">
					<view class="textTitle">
						古瓷器智能检索与知识科普平台的设计与实现
					</view>
					<view class="textChn">
						GUCIQIZHINENGJIANSUOYUZHISHIKEPU
					</view>
				</view>
			</view>
		</u-transition>
		<u-loading-icon text="加载中" textSize="12" :show="true" color="white" textColor="white">
		</u-loading-icon>
		<view class="line">
			<u-line color="#fff" length="60%" margin="50rpx auto"></u-line>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				show: true
			}
		},
		methods: {

		},
		onLoad() {
			setTimeout(function() {
				uni.navigateTo({
					url: '/pages/login/login'
				})
			}, 4000)
		}
	}
</script>

<style lang="less" scoped>
	.page {
		position: relative;

		/deep/.u-loading-icon {
			margin-top: 300rpx;
		}

		.bg {
			opacity: 0.8;
			z-index: -2;
			width: 100%;
			height: 100%;
			position: fixed;
			top: 0%;
		}

		.logo {
			position: absolute;
			position: fixed;
			margin-top: 250rpx;
			left: 50%;
			transform: translateX(-50%);
			width: 200rpx;

		}

		.textStyle {
			display: flex;

			.textTitle,
				{
				// background-color: pink;
				width: 40rpx;
				margin-left: 600rpx;
				margin-top: 175rpx;
				font-weight: 600;
				font-family: 'Courier New', Courier, monospace;
				font-size: 35rpx;
				// font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
			}

			.textChn {
				width: 20rpx;
				height: 500rpx;
				font-size: 30rpx;
				margin-top: 250rpx;
				margin-left: 30rpx;
				font-family: 'Courier New', Courier, monospace;
				word-wrap: break-word
			}
		}
	}
</style>
