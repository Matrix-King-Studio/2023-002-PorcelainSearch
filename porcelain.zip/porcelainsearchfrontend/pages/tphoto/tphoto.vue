<template>
	<view class="page">
		<!-- <u-upload name="1" multiple :maxCount="1">
		</u-upload> -->
		<view class="image" @click="image">
			<image src="https://demo-1311835527.cos.ap-beijing.myqcloud.com/porcelain%2F/images/拍照.png"
				mode="aspectFit"></image>
		</view>

	</view>
</template>

<script>
	import {
		request
	} from "../api/request.js"
	export default {
		data() {
			return {
				checkUrl: '',
			}
		},
		methods: {
			image() {
				// this.list.push(res.tempFilePaths[0])
				uni.chooseImage({
					count: 1,
					sizeType: ['original', 'compressed'],
					sourceType: ['camera', 'album'], //这要注意，camera掉拍照，album是打开手机相册
					success: (res) => {
						// TODO 上传图片拿图片的 url
						this.upload(res.tempFilePaths[0])

						// console.log(res);
						// const tempFilePaths = res.tempFilePaths;
						// this.takePhotos = res.tempFilePaths[0];
						// console.log(this.takePhotos)
						// this.list.push(res.tempFilePaths[0])
						// console.log(this.list)

					}
				});
			},
			// 删除图片
			// deletePic(event) {
			// 	this[`fileList${event.name}`].splice(event.index, 1)
			// },
			// 新增图片
			// async afterRead(event) {
			// 	// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
			// 	let lists = [].concat(event.file)
			// 	let fileListLen = this[`fileList${event.name}`].length
			// 	lists.map((item) => {
			// 		this[`fileList${event.name}`].push({
			// 			...item,
			// 			status: 'uploading',
			// 			message: '上传中'
			// 		})
			// 	})
			// 	for (let i = 0; i < lists.length; i++) {
			// 		const result = await this.uploadFilePromise(lists[i].url)
			// 		let item = this[`fileList${event.name}`][fileListLen]
			// 		this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
			// 			status: 'success',
			// 			message: '',
			// 			url: result
			// 		}))
			// 		fileListLen++
			// 	}
			// },
			upload(url) {
				uni.uploadFile({
					url: 'http://182.92.3.1:9979/porcelain/storage/cos/upload',
					filePath: url,
					name: 'file',
					success: (res) => {
						console.log(res)
						var r = JSON.parse(res.data)
						this.checkUrl = r.fileList[0].fileUrl
						console.log('file url: ' + this.checkUrl)


						// setTimeout(() => {
						// 	resolve(res)
						// }, 5000)

						// TODO 利用图片的url 调用图像识别接口, 获取瓷器详情
						this.check()

					}
				})
			},

			check() {
				this.$request({
					url: '/ai/check',
					method: 'POST',
					data: {
						url: this.checkUrl
					},
				}).then(res => {
					console.log(res)
					uni.navigateTo({
						url: '/pages/introduce/introduce?id=' + res.data.res.id
					})
				});
			}
		}

	}
</script>

<style lang="less" scoped>
	.page {
		background-color: rgba(0, 0, 0, 0.9);
		width: 750rpx;
		height: 1500rpx;

		.image {
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			width: 60rpx;
			height: 60rpx;
			padding: 25rpx;
			border-radius: 50%;
			border: 5rpx solid #fff;

			image {
				width: 100%;
				height: 100%;
			}
		}

		.takePhotos {
			background-color: black;
			width: 100%;
			height: 100%;
		}
	}
</style>
