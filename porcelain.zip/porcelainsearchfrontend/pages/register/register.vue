<template>
	<view class="page">
		<image src="https://demo-1311835527.cos.ap-beijing.myqcloud.com/porcelain%2F/images/background.png" mode="">
		</image>
		<view class="register">
			<span @click="loginBts()">登录</span><span>帮助</span>
		</view>
		<view class="box">
			<view class="title">
				<p>欢迎注册账号！</p>
				<p>瓷器检索与科普</p>
			</view>

			<view class="formStyle">
				<u-form class="formStyle" :model="registerForm" ref="registerForm" :rules="registerRules">
					<u-form-item label="昵称" prop="username">
						<u-input v-model="registerForm.username" placeholder="请输入昵称!" />
					</u-form-item>
					<u-form-item label="邮箱" prop="email">
						<u-input v-model="registerForm.email" type="email" placeholder="请输入邮箱地址!" />
					</u-form-item>
					<u-form-item label="密码" prop="password">
						<u-input v-model="registerForm.password" placeholder="请输入密码!" password />
					</u-form-item>
					<u-form-item label="重复" prop="checkPassword">
						<u-input v-model="registerForm.checkPassword" placeholder="请再次输入密码!" password />
					</u-form-item>
					<view class="codeForm">
						<u-form-item prop="code">
							<u-input class="codeBts" v-model="registerForm.code" placeholder="请输入验证码!" />
						</u-form-item>
						<u-form-item>
							<u-button @click="getRegister">获取验证码</u-button>
						</u-form-item>
					</view>

					<u-form-item class="btsStyle">
						<u-button @click="registerSubmit" plain shape="square" size="medium">
							注册
						</u-button>
						<u-button @click="resetForm" plain shape="square" size="medium">
							重置
						</u-button>
					</u-form-item>
				</u-form>
			</view>

			<!-- <view class="btsStyle">
				<u-button plain shape="square" size="medium">
					注册账号
				</u-button>
				<u-button plain shape="square" size="medium">
					注册账号
				</u-button>
			</view> -->
		</view>

	</view>
</template>

<script>
	import {
		getRegisterData
	} from "../api/userLogin.js"
	import {
		getRegister
	} from "../api/userLogin.js"
	export default {
		data() {
			var checkEmail = (rule, value, callback) => {
				// 验证邮箱的正则表达式
				const regEmail = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-])+/
				if (regEmail.test(value)) {
					// 合法的邮箱
					return callback()
				}
				callback(new Error('请输入合法的邮箱！'))
			};
			var validatePass = (rule, value, callback) => {
				if (value === "") {
					callback(new Error("请输入密码"));
				} else {
					if (this.registerForm.checkPassword !== "") {
						this.$refs.registerFormRef.validateField("checkPassword");
					}
					callback();
				}
			};
			var validatePass2 = (rule, value, callback) => {
				if (value === "") {
					callback(new Error("请再次输入密码"));
				} else if (value !== this.registerForm.password) {
					callback(new Error("两次输入密码不一致!"));
				} else {
					callback();
				}
			};
			return {
				registerForm: {
					email: '',
					password: '',
					checkPassword: '',
					code: '',
					username: ''
				},
				registerRules: {
					username: [{
						required: true,
						message: '请输入昵称！',
						trigger: ['change', 'blur'],
					}, ],
					email: [{
							required: true,
							message: '请输入邮箱地址！',
							trigger: ['change', 'blur'],
						},
						{
							validator: checkEmail,
							trigger: 'blur',
						},
						// {
						// 	min: 5,
						// 	message: '请输入合法的邮箱地址！',
						// 	trigger: ['change', 'blur'],
						// }
					],
					password: [{
							// required: true,
							// message: '请输入密码！',
							// trigger: ['change', 'blur'],
							validator: validatePass,
							trigger: "blur"
						},
						{
							min: 6,
							max: 15,
							message: '字符应为6~15个！',
							trigger: ['change', 'blur'],
						}
					],
					checkPassword: [{
							// required: true,
							// message: '请再次输入密码！',
							// trigger: ['change', 'blur'],
							validator: validatePass2,
							trigger: "blur"
						},
						{
							min: 6,
							max: 15,
							message: '字符应为6~15个！',
							trigger: ['change', 'blur'],
						}
					],
					code: [{
							required: true,
							message: '请输入验证码！',
							trigger: ['change', 'blur'],
						},
						{
							min: 6,
							max: 6,
							message: '字符应为6个！',
							trigger: ['change', 'blur'],
						}
					],
				}
			}
		},
		methods: {
			// submit() {
			// 	this.$refs.uForm.validate(valid => {
			// 		if (valid) {
			// 			console.log('验证通过');
			// 		} else {
			// 			console.log('验证失败');
			// 		}
			// 	});
			// },
			registerSubmit() {
				this.$request({
					url: '/user/register',
					method: 'POST',
					data: {
						code: this.registerForm.code,
						email: this.registerForm.email,
						password: this.registerForm.password,
						username: this.registerForm.username
					},
				}).then (res => {
					console.log(res.data);
					if (res.data.code !== 0) {
						uni.showToast({
							title: '注册失败',
							//将值设置为 success 或者直接不用写icon这个参数
							icon: 'error',
							//显示持续时间为 2秒
							duration: 2000
						})
						console.log("失败")
					} else {
						uni.showToast({
							title: '注册成功',
							//将值设置为 success 或者直接不用写icon这个参数
							icon: 'success',
							//显示持续时间为 2秒
							duration: 2000
						})
						console.log("成功")
						uni.navigateTo({
							url: '/pages/login/login'
						})
					}
				});
				// this.$refs.registerForm.validate().then(res => {
				// 	console.log('成功：', res);
				// }).catch(err => {
				// 	console.log('失败：', err);
				// })
			},

			loginBts() {
				uni.navigateBack({
					url: '/pages/login/login'
				})
			},
			getRegister() {
				this.$request({
					url: '/user/sendCode',
					method: 'POST',
					data: {
						email: this.registerForm.email,
					},
				}).then (res => {
					console.log(res.data);
					// console.log(this.registerForm.email);
					if (res.data.code !== 0) {
						uni.showToast({
							title: res.data.msg,
							//将值设置为 success 或者直接不用写icon这个参数
							icon: 'error',
							//显示持续时间为 2秒
							duration: 2000
						})
					} else {
						uni.showToast({
							title: '验证码发送成功',
							//将值设置为 success 或者直接不用写icon这个参数
							icon: 'success',
							//显示持续时间为 2秒
							duration: 2000
						})
						console.log("成功")
					}
				})
			},
			resetForm () {
				this.registerForm = {}
			},
			// showErrorToast() {
			// 	this.$refs.loginFormToastRef.show({
			// 		title: "邮箱或密码输入错误！",
			// 		type: 'error',
			// 		icon: true
			// 		// url: '/pages/user/index'
			// 	})
			// },
			// showSuccessToast() {
			// 	this.$refs.loginFormToastRef.show({
			// 		title: '登录成功',
			// 		type: 'success',
			// 		// url: '/pages/user/index'
			// 	})
			// }
		},
		onReady() {
			this.$refs.registerForm.setRules(this.registerRules);
		}
	}
</script>

<style lang="less" scoped>
	.page {

		// background-image: url(../static/images/background.png);
		image {
			opacity: 1;
			z-index: -2;
			width: 100%;
			height: 100%;
			position: fixed;
			top: 0%;
		}

	}

	.register {
		margin-top: 30rpx;
		margin-left: 530rpx;
		display: flex;
		justify-content: space-between;
		width: 160rpx;

		span {
			font-size: 27rpx;
			color: #693c22;
		}
	}

	.box {
		width: 90%;
		border-radius: 25rpx;
		margin: 35rpx auto;
		padding: 25rpx 0rpx 1rpx 0;
		box-shadow: 3rpx 3rpx 10rpx 3rpx rgba(0, 0, 0, 0.2);
		background-color: rgba(255, 255, 255, 0.9);
	}

	.title {
		margin: 0rpx 0 0 50rpx;
		height: 200rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-between;

		p:nth-of-type(1) {
			color: #a4836c;
			font-size: 40rpx;
		}

		p:nth-of-type(2) {
			color: #663820;
			font-size: 60rpx;
		}
	}

	.formStyle {
		// width: 80%;
		margin: 50rpx 30rpx;

		/deep/.u-form {
			margin-left: 30rpx;
			width: 85% !important;
		}

		/deep/.u-form-item__body__left__content {
			display: flex;
			// margin-left: rpx;

			.u-form-item__body__left__content__label {
				font-size: 25rpx;
				color: #a4836c;
			}
		}

		/deep/.u-input {
			// margin-right: 25rpx;
			// width: 75% !important;
			padding: 0 !important;
			background-color: #fff;
			// .u-input u-border u-radius u-square {
			// 	height: 20rpx !important;
			// }

		}
	}

	/deep/.u-input__content__field-wrapper__field.data-v-fdbb9fe6 {
		height: 30rpx !important;
		font-size: 25rpx !important;
		padding: 4rpx;
		padding-left: 15rpx;
	}

	.codeForm {
		display: flex;
		// background-color: #6c93c0;

		/deep/.u-input {
			width: 200rpx;
			margin-left: 160rpx;
		}

		/deep/.u-button {
			height: 50rpx;
			margin-top: 3rpx;
			margin-left: 30rpx;
			font-size: 19rpx;
			width: 125rpx;
			color: #693c22;
			box-shadow: 5rpx 5rpx 5rpx 5rpx rgba(255, 255, 255, 0.5);
		}
	}

	/deep/.u-button--normal.data-v-3bf2dba7 {
		padding: 0 5rpx !important;
	}

	/deep/.btsStyle {
		display: flex !important;
		flex-direction: row;
		margin: 0 auto;
		// width: 75%;
		margin-top: -35rpx;
	}

	/deep/.u-button {
		margin: 10rpx auto;
		border-radius: 10rpx;
		background-color: #d2c1b6 !important;
		box-shadow: 6rpx 6rpx 6rpx 5rpx rgba(108, 147, 192, 0.2);
	}

	/deep/.u-form-item__body__right__content__slot.data-v-5e7216f1 {
		flex-direction: row;
	}

	/deep/.u-button--plain.u-button--info.data-v-3bf2dba7 {
		margin-left: 100rpx;
		width: 160rpx;
		color: #693c22;
		box-shadow: 1rpx 1rpx 1rpx 1rpx rgba(255, 255, 255, 0.5);
	}

	.codeBts {
		width: 50%;
	}

	/deep/.u-input data-v-fdbb9fe6 u-border u-radius u-square {
		width: 300rpx !important;
		background-color: pink !important;
	}
</style>
