<template>
	<view class="page">
		<u-toast ref="loginFormToastRef" />
		<image src="https://demo-1311835527.cos.ap-beijing.myqcloud.com/porcelain%2F/images/background.png" mode="">
		</image>
		<view class="register">
			<span @click="registerBts()">注册</span><span>帮助</span>
		</view>
		<view class="box">
			<view class="title">
				<p>欢迎登录！</p>
				<p>瓷器检索与科普</p>
			</view>
			<view class="formStyle">
				<u-form class="formStyle" :model="loginForm" ref="uForm" :rules="loginRules">
					<u-form-item label="邮箱" prop="email">
						<u-input v-model="loginForm.email" type="email" placeholder="请输入邮箱地址!" />
					</u-form-item>
					<u-form-item label="密码" prop="password">
						<u-input v-model="loginForm.password" placeholder="请输入密码!" password />
					</u-form-item>
				</u-form>
			</view>

			<view class="btsStyle">
				<u-button @click="login" plain shape="square" size="medium">
					登录
				</u-button>
			</view>
		</view>

	</view>
</template>

<script>
	import {
		getLoginData
	} from "../api/userLogin.js"

	import {
		request
	} from '../api/request.js'

	export default {
		data() {
			var checkEmail = (rule, value, callback) => {
				// 验证邮箱的正则表达式
				const regEmail = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-])+/
				if (regEmail.test(value)) {
					// 合法的邮箱
					return callback()
				}
				callback(new Error('请输入合法的邮箱！'))
			};
			return {
				loginForm: {
					email: '',
					password: ''
				},
				loginRules: {
					email: [{
							required: true,
							message: '请输入邮箱地址！',
							trigger: ['change', 'blur'],
						},
						{
							validator: checkEmail,
							trigger: 'blur',
						},
					],
					password: [{
							required: true,
							message: '请输入密码！',
							trigger: ['change', 'blur'],
						},
						{
							min: 6,
							max: 15,
							message: '字符应为6~15个！',
							trigger: ['change', 'blur'],
						}
					],
				}
			}
		},
		onLoad() {
			// console.log(uni.request)
			// this.login();
		},
		methods: {
			login() {
				this.$request({
					url: '/user/login',
					method: 'POST',
					data: {
						email: this.loginForm.email,
						password: this.loginForm.password
					}
				}).then(res => {
					console.log(res.data);
					if (res.data.code != 0) {
						uni.showToast({
							title: '失败提示',
							icon: 'error',
							duration: 2000
						})
						// console.log(res.data.code !== 0)
						// console.log("失败")
						// console.log(res.data.code)
					} else {
						uni.showToast({
							title: '成功提示',
							icon: 'success',
							duration: 2000,
						})
						uni.setStorageSync('token', res.data.token);
						console.log("成功")
						uni.switchTab({
							url: '../classify/classify'
						})
					}
				});

				// this.$refs.uForm.validate(valid => {
				// 	if (valid) {
				// 		console.log('验证通过');
				// 	} else {
				// 		console.log('验证失败');
				// 	}
				// });
			},
			registerBts() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/register/register'
				})
			},
			// showErrorToast() {
			// 	this.$refs.loginFormToastRef.show({
			// 		title: "邮箱或密码输入错误！",
			// 		type: 'error',
			// 		icon: true
			// 		// url: '/pages/user/index'
			// 	})
			// },
			// showSuccessToast() {
			// 	this.$refs.loginFormToastRef.show({
			// 		title: '登录成功',
			// 		type: 'success',
			// 		// url: '/pages/user/index'
			// 	})
			// }
			// login() {
			// 	uni.navigateTo({
			// 		url: '/pages/classify/classify'
			// 	})
			// }
		},
		onReady() {
			this.$refs.uForm.setRules(this.loginRules);
		},
	}
</script>

<style lang="less" scoped>
	.page {

		// background-image: url(../static/images/background.png);
		image {
			opacity: 1;
			z-index: -2;
			width: 100%;
			height: 100%;
			position: fixed;
			top: 0%;
		}

	}

	.register {
		margin-top: 30rpx;
		margin-left: 530rpx;
		display: flex;
		justify-content: space-between;
		width: 160rpx;

		span {
			font-size: 27rpx;
			color: #663820;
		}
	}

	.box {
		width: 90%;
		border-radius: 25rpx;
		margin: 100rpx auto;
		padding: 50rpx 0rpx 55rpx 0;
		box-shadow: 3rpx 3rpx 10rpx 3rpx rgba(0, 0, 0, 0.2);
		background-color: rgba(255, 255, 255, 0.9);
	}

	.title {
		margin: 0rpx 0 0 50rpx;
		height: 200rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-between;

		p:nth-of-type(1) {
			color: #a4836c;
			font-size: 40rpx;
		}

		p:nth-of-type(2) {
			color: #663820;
			font-size: 60rpx;
		}
	}

	.formStyle {
		// width: 80%;
		margin: 50rpx 30rpx;

		/deep/.u-form {
			margin-left: 30rpx;
			width: 90%;
		}

		/deep/.u-form-item__body__left__content {
			display: flex;
			// margin-left: rpx;

			.u-form-item__body__left__content__label {
				font-size: 25rpx;
				color: #a4836c;
			}
		}

		/deep/.u-input {
			// margin-right: 25rpx;
			background-color: #fff;
			width: 88%;
		}

	}

	.btsStyle {
		border: 1px solid #fff;
		border-radius: 10rpx;
		margin: 0 auto;
		width: 75%;
		margin-top: -35rpx;
	}

	/deep/.u-button {
		border-radius: 10rpx;
		background-color: #d2c1b6 !important;
		box-shadow: 5rpx 5rpx 5rpx 5rpx rgba(255, 255, 255, 0.5);
	}

	/deep/.u-button--plain.u-button--info.data-v-3bf2dba7 {
		color: #693c22;
	}
</style>
