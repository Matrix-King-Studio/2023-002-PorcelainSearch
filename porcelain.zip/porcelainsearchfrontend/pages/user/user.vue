<template>
	<view>
		<view class="headPortrait">
			<u-avatar :src="user.avatar" size="65" v-model="user"></u-avatar>
			<view class="nicknameBox">
				<p>{{user.username}}</p>
			</view>
		</view>
		<u-divider text="分割线" :dot="true"></u-divider>
		<view class="functionBox">
			<view>
				<view class="followCntNum">{{user.followCnt}}</view>
				<text>关注</text>
			</view>
			<view>
				<view class="fanCntNum">{{user.fanCnt}}</view>
				<text>粉丝</text>
			</view>
			<view>
				<view class="visitCntNum">{{user.visitCnt}}</view>
				<text>访客</text>
			</view>
			<view>
				<view class="loveCntNum">{{user.loveCnt}}</view>
				<text>喜欢我</text>
			</view>
			<!-- <u-grid :border="false" @click="click" col="4">
				<u-grid-item v-for="(baseListItem,baseListIndex) in baseList" :key="baseListIndex">

					<text class="grid-number">{{baseListItem.number}}</text>
					<text class="grid-text">{{baseListItem.title}}</text>
				</u-grid-item>
			</u-grid>
			<u-toast ref="uToast" /> -->
			<view class="article"></view>
		</view>
		<view class="welcome">
			欢迎来到我的主页~
		</view>
	</view>
</template>

<script>
	import {
		getUser
	} from "../api/userLogin.js"
	export default {
		data() {
			return {
				// text: '无头像'
				user: {
					id: '',
					avatar: '',
					username: '',
					email: '',
					articleList: [],
					followCnt: '',
					fanCnt: '',
					visitCnt: '',
					loveCnt: '',
				},
				baseList: [{
						number: '0',
						title: '关注'
					},
					{
						number: '0',
						title: '粉丝'
					},
					{
						number: '0',
						title: '访客'
					},
					{
						number: '0',
						title: '喜欢我'
					},
				]
			}
		},
		onLoad() {
			this.getUserMsg()
		},
		methods: {
			click(name) {
				// this.$refs.uToast.success(`点击了第${name}个`)
			},
			// http://porcelain.vnuo.com.cn:9979/porcelain
			getUserMsg() {
				uni.request({
					url: 'http://182.92.3.1:9979/porcelain/user/info',
					method: 'POST',
					header: {
						token: uni.getStorageSync('token')
					}, //请求头的信息
				}).then(result => {

					let [err, res] = result;
					if (res.data.code == 0) {
						console.log(res.data);
						this.user = res.data.user;

					};
					if (res.data.code != 0) {
						console.log(res.data.msg);
					}
				})
			}
		}
	}
</script>

<style lang="less" scoped>
	.headPortrait {
		display: flex;
		justify-content: space-around;
		justify-content: center;
		align-items: center;
		margin: 0 auto;
		margin-top: 50rpx;
		width: 650rpx;
		height: 160rpx;
		border-radius: 100rpx;
		background-color: #382d25;
		box-shadow: 1px 1px 10px 1px rgba(0, 0, 0, 0.1);

		/deep/.u-avatar {
			// margin-left: 50rpx;
			// margin-top: 20rpx;
			// padding-bottom: 0;
		}

		.nicknameBox {
			// margin-top: 65rpx;
			margin-left: 30rpx;
			width: 400rpx;
			height: 50rpx;

			p {
				color: white;
				font-weight: 700;
				font-size: 32rpx;
			}
		}
	}

	.functionBox {
		display: flex;
		justify-content: space-around;
		align-items: center;
		height: 125rpx;
		padding-top: 5rpx;
		margin-top: -10rpx;
		box-shadow: 1px 1px 10px 1px rgba(0, 0, 0, 0.1);
		justify-content: space-around;

		view {
			// display: flex;
			// justify-content: center;
			// width: 160rpx;
			height: 120rpx;
			// background-color: pink;

			.followCntNum,
			.fanCntNum,
			.visitCntNum,
			.loveCntNum {
				width: auto;
				height: 60rpx;
				// background-color: skyblue;
				margin-left: 70rpx;
				font-size: 17px;
				color: #2d2211;
				padding: 10rpx 0 20rpx 0rpx;
				/* #ifndef APP-PLUS */
				box-sizing: border-box;
				/* #endif */
			}

			text {
				margin-left: 50rpx;
				font-size: 14px;
				color: #909399;
				// padding: 10rpx 0 20rpx 0rpx;
				/* #ifndef APP-PLUS */
				box-sizing: border-box;
				/* #endif */
			}
		}

		.grid-text {}
	}

	.welcome {
		margin-top: 15rpx;
		margin-left: 50rpx;
		font-family: 'Times New Roman', Times, serif;
		color: #909399;
		background-color: #ffffff;
		height: 85rpx;
	}
</style>
