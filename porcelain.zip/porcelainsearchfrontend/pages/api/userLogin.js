import request from "./request.js"

export const getLoginData = (data) => {
	return uni.$post('/user/login', data)
}

export const getRegisterData = (data) => {
	return uni.$post('/user/register', data)
}

export const getRegister = (data) => {
	return uni.$post('/user/sendCode', data)
}

export const getUser = (data) => {
	return uni.$post('/user/info', data)
}
