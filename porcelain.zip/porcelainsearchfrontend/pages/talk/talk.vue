<template>
	<view>
		<view class="talkBox" v-for="article in articleList" :key="article.id">
			<view class="functBox">
				<view class="userPhoto">
					<image :src="article.avatar" mode="aspectFit"></image>
				</view>
				<view class="nameBox">{{article.username}}</view>
			</view>
			<view class="contentBox">
				<view class="textBox" @click="talkBts(article.id)">
					<view class="talk-in-bts">
						{{article.content}}
					</view>
				</view>
				<view class="iconBox">
					<view class="thumbUp">
						<u-icon name="thumb-up" size="40rpx"
							:color="article.loveStatus === 1 ? 'red' : 'u-content-color'"
							@click="love(article.id, article.loveStatus)">
						</u-icon>
					</view>
					<view class="number">{{article.loveCnt}}</view>
					<view class="chat">
						<u-icon name="chat" size="40rpx"
							@click="talkBts(article.id)">
						</u-icon>
					</view>
					<view class="number">{{article.commentCnt}}</view>
					<view class="shareSquare">
						<button :data-id='article.id' open-type="share" style="
						margin: 0;
						padding: 0;
						border: none !important;
						outline: none;
						border-radius: 0;
						background-color: transparent;
						line-height: inherit;
						">
							<u-icon name="share-square" size="40rpx"></u-icon>
						</button>
					</view>
				</view>
			</view>

		</view>
	</view>
</template>

<script>
	// import request from "../api/request.js"
	export default {
		data() {
			return {
				articleList: []
			}
		},
		methods: {
			talkBts(id) {
				uni.navigateTo({
					url: '../talk-in/talk-in?id=' + id
				})
			},
			// changeThumb() {
			// 	this.changeThumbColor = !this.changeThumbColor
			// },
			onLoad() {
				this.getArticleList()
			},
			getArticleList() {
				this.$request({
					url: '/article/list',
					method: 'GET',
				}).then(res => {
					console.log(res.data);
					if (res.data.code != 0) {
						uni.showToast({
							title: '失败提示',
							icon: 'error',
							duration: 2000
						})
					} else {
						this.articleList = res.data.list
						console.log(this.articleList)
					}
				});

			},
			// parentIndex: 当前评论的父评论在 parentCommentList 中的索引, 如果自己就是父评论, 那么它是没有父评论的, 传 null
			// curIndex: 当前评论的在对应 parentCommentList || childCommentList 中的索引
			love(id, loveStatus) {
				console.log(id)
				this.$request({
					url: '/article/love',
					method: 'POST',
					data: {
						id: id,
						status: loveStatus
					}
				}).then(res => {
					console.log(res.data)
					if (res.data.code == 0) {
						this.getArticleList()
					}

				});

			},
			onShareAppMessage: function (options) {
			    if (options.from === 'button') {
			        return {
			          title: '讨论',
			          path: '/pages/talk-in/talk-in?id=' + options.target.dataset.id,
			          // imageUrl:goods_img //不设置则默认为当前页面的截图
			        }
			    }
			},
			// share(id) {
			// 	console.log('http://porcelain.vnuo.com.cn:9979/porcelain/article/' + id)
			// },
		}
	}
</script>

<style lang="less" scoped>
	.talkBox {
		margin: 15rpx auto;
		width: 99%;
		// height: 350rpx;
		background-color: #fff !important;
		box-shadow: 1px 1px 2px 2px rgba(0, 0, 0, 0.1);

		.contentBox {
			position: relative;
			// height: 190rpx;
			// background-color: pink;

			.textBox {
				// margin: 0 auto;
				margin-left: 9%;
				width: 84%;
				height: auto;
				padding: 10rpx 8rpx;
				// background-color: pink;

				.talk-in-bts {
					margin-left: 10rpx;
					padding: 5rpx 0rpx 40rpx 5rpx;
					height: 100%;
					font-size: 30rpx;
					color: #404040;
					line-height: 140%;
					// font-family: 'Courier New', Courier, monospace;
					// font-family: Impact, Haettenschweiler, 'Arial Narrow Bold', sans-serif;
					// font-family: cursive;
					// font-family: monospace;
					font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
					font-weight: 400;
				}
			}

			.iconBox {
				position: absolute;
				bottom: 0%;
				display: flex;
				justify-content: space-around;
				align-items: center;
				width: 200rpx;
				height: 45rpx;
				margin-left: 70%;
				padding-bottom: 20rpx;
				// background-color: #916f58;

				view {
					margin-top: 30rpx;
				}
			}



			image {
				position: absolute;
				z-index: -1;
				width: 100%;
				height: 100%;
			}
		}

		.functBox {
			display: flex;
			// justify-content: space-around;
			border-radius: 10rpx;
			// background-color: #f6f6f6;
			height: 80rpx;

			.userPhoto {
				width: 65rpx;
				height: 65rpx;
				margin-left: 20rpx;
				margin-top: 8rpx;
				// background-image: url('../../static/logo.png');
				// background-repeat: no-repeat;
				// background-position: center;
				// background-size: 100% 100%;

				image {
					width: 100%;
					height: 100%;
					border-radius: 50%;
					border: 3rpx solid #916f58;
				}
			}

			.nameBox {
				width: 200rpx;
				height: 80rpx;
				margin: 20rpx 0rpx 20rpx 20rpx;
				font-size: 27rpx;
				color: #404040;
				font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
				// background-color: pink;
			}


		}
		button::after{
		  border: none;
		}
	}
</style>
