import App from './App'
import uView from "uview-ui"
Vue.use(uView);

// #ifndef VUE3
import Vue from 'vue'


// 挂载request
import {
	request
} from "./pages/api/request.js"

Vue.prototype.$request = request


// 生存环境禁用常见的错误提示
Vue.config.productionTip = false


App.mpType = 'app'
// 创建vue实例
const app = new Vue({
	...App
})


// 挂载vue实例
app.$mount()
// #endif


// #ifdef VUE3
import {
	createSSRApp
} from 'vue'
export function createApp() {
	const app = createSSRApp(App)
	return {
		app
	}
}
// #endif
